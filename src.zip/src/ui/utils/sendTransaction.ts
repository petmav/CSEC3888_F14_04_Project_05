import {
  ALIAS_ADDRESS,
  CHAINS_ENUM,
  EVENTS,
  INTERNAL_REQUEST_ORIGIN,
  INTERNAL_REQUEST_SESSION,
  KEYRING_TYPE,
  KEYRING_CATEGORY_MAP,
} from '@/constant';
import { intToHex, WalletControllerType } from '@/ui/utils';
import { findChain, isTestnet } from '@/utils/chain';
import {
  calcGasLimit,
  calcMaxPriorityFee,
  checkGasAndNonce,
  explainGas,
  getGasTokenBalance,
  getPendingTxs,
  is7702Tx,
} from '@/utils/transaction';
import {
  ExplainTxResponse,
  GasLevel,
  ParseTxResponse,
  Tx,
  TxPushType,
} from '@rabby-wallet/rabby-api/dist/types';
import BigNumber from 'bignumber.js';
import Browser from 'webextension-polyfill';
import eventBus from '@/eventBus';
import {
  parseAction,
  fetchActionRequiredData,
  ParsedTransactionActionData,
  ActionRequireData,
} from '@rabby-wallet/rabby-action';
import stats from '@/stats';
import { getCexInfo } from '../state/exchange';
import { Account } from '@/background/service/preference';
import {
  buildTempoTransaction,
  isTempoBatchSupportedAccountType,
  isTempoChain,
  shouldUseTempoTransaction,
  TxWithTempoExtras,
  toTempoCallsTx,
} from '@/utils/tempo';

// fail code
export enum FailedCode {
  GasNotEnough = 'GasNotEnough',
  GasTooHigh = 'GasTooHigh',
  SubmitTxFailed = 'SubmitTxFailed',
  SimulationFailed = 'SimulationFailed',
  DefaultFailed = 'DefaultFailed',
}

type ProgressStatus = 'building' | 'builded' | 'signed' | 'submitted';

const checkEnoughUseGasAccount = async ({
  gasAccount,
  wallet,
  transaction,
  currentAccountType,
}: {
  transaction: Tx;
  currentAccountType: string;
  wallet: WalletControllerType;
  gasAccount?: {
    sig: string | undefined;
    accountId: string | undefined;
  };
}) => {
  let gasAccountCanPay: boolean = false;

  // native gas not enough check gasAccount
  let gasAccountVerfiyPass = true;
  let gasAccountCost;
  try {
    gasAccountCost = await wallet.openapi.checkGasAccountTxs({
      sig: gasAccount?.sig || '',
      account_id: gasAccount?.accountId || '',
      tx_list: [transaction],
    });
  } catch (e) {
    gasAccountVerfiyPass = false;
  }
  gasAccountCanPay =
    gasAccountVerfiyPass &&
    currentAccountType !== KEYRING_TYPE.WalletConnectKeyring &&
    currentAccountType !== KEYRING_TYPE.WatchAddressKeyring &&
    !!gasAccountCost?.balance_is_enough &&
    !gasAccountCost.chain_not_support &&
    !!gasAccountCost.is_gas_account;

  return gasAccountCanPay;
};

/**
 * send transaction without rpcFlow
 * @param tx
 * @param chainServerId
 * @param wallet
 * @param ignoreGasCheck if ignore gas check
 * @param onProgress callback
 * @param gasLevel gas level, default is normal
 * @param lowGasDeadline low gas deadline
 * @param isGasLess is gas less
 * @param isGasAccount is gas account
 * @param autoUseGasAccount when gas balance is low , auto use gas account for gasfee
 * @param onUseGasAccount use gas account callback
 */
export const sendTransaction = async ({
  tx,
  chainServerId,
  wallet,
  ignoreGasCheck,
  onProgress,
  gasLevel,
  lowGasDeadline,
  isGasLess,
  isGasAccount,
  autoUseGasAccount,
  waitCompleted = true,
  pushType = 'default',
  ignoreGasNotEnoughCheck,
  onUseGasAccount,
  ga,
  sig: _sig,
  ignoreSimulationFailed,
  extra,
  session,
  account: _account,
}: {
  tx: Tx;
  chainServerId: string;
  wallet: WalletControllerType;
  ignoreGasCheck?: boolean;
  ignoreGasNotEnoughCheck?: boolean;
  ignoreSimulationFailed?: boolean;
  onProgress?: (status: ProgressStatus) => void;
  onUseGasAccount?: () => void;
  gasLevel?: GasLevel;
  lowGasDeadline?: number;
  isGasLess?: boolean;
  isGasAccount?: boolean;
  autoUseGasAccount?: boolean;
  waitCompleted?: boolean;
  pushType?: TxPushType;
  ga?: Record<string, any>;
  sig?: string;
  extra?: {
    preExecResult?: ExplainTxResponse;
    actionData?: ParseTxResponse;
  };
  session?: Parameters<typeof wallet.ethSendTransaction>[0]['session'];
  account?: Account;
}) => {
  const shouldUseTempoCallsForGasAccount = (gasAccountEnabled?: boolean) =>
    !!gasAccountEnabled &&
    isTempoChain(chainServerId) &&
    isTempoBatchSupportedAccountType(account.type);
  let sig = _sig;
  onProgress?.('building');
  const chain = findChain({
    serverId: chainServerId,
  })!;
  const support1559 = chain.eip['1559'];
  const account = _account || (await wallet.getCurrentAccount())!;
  const { address, ...currentAccount } = account;
  const recommendNonce =
    tx.nonce ||
    (await wallet.getRecommendNonce({
      from: tx.from,
      chainId: chain.id,
      nonceKey: (tx as TxWithTempoExtras<Tx>).nonceKey as
        | string
        | number
        | bigint
        | undefined,
    }));

  // get gas
  let normalGas = gasLevel;
  if (!normalGas) {
    const gasMarket = await wallet.gasMarketV2({
      chain,
      tx,
    });
    normalGas = gasMarket.find((item) => item.level === 'normal')!;
  }

  const signingTxId = await wallet.addSigningTx(tx);

  let reportGasLevel = normalGas.level;
  if (!reportGasLevel) {
    reportGasLevel = 'normal';
    try {
      reportGasLevel = await wallet.getReportGasLevel();
    } catch (error) {
      console.error('getReportGasLevel error', error);
    }
  }

  wallet.reportStats('createTransaction', {
    type: currentAccount.brandName,
    category: KEYRING_CATEGORY_MAP[currentAccount.type],
    chainId: chain.serverId,
    createdBy: ga ? 'rabby' : 'dapp',
    source: ga?.source || '',
    trigger: ga?.trigger || '',
    networkType: chain?.isTestnet ? 'Custom Network' : 'Integrated Network',
    swapUseSlider: ga?.swapUseSlider ?? '',
    gasLevel: reportGasLevel,
  });

  // pre exec tx
  const preExecResult =
    extra?.preExecResult ||
    (await wallet.openapi.preExecTx({
      tx: shouldUseTempoCallsForGasAccount(isGasAccount)
        ? (toTempoCallsTx(
            {
              ...tx,
              nonce: recommendNonce,
              data: tx.data,
              value: tx.value || '0x0',
              gasPrice: intToHex(Math.round(normalGas.price)),
            },
            { stripTopLevelData: true }
          ) as any)
        : ({
            ...tx,
            nonce: recommendNonce,
            data: tx.data,
            value: tx.value || '0x0',
            gasPrice: intToHex(Math.round(normalGas.price)),
          } as any),
      origin: INTERNAL_REQUEST_ORIGIN,
      address: address,
      updateNonce: true,
      pending_tx_list: await getPendingTxs({
        recommendNonce,
        wallet,
        address,
        chainId: tx.chainId,
      }),
    }));

  const gasToken = await getGasTokenBalance({
    wallet,
    chainId: chain.id,
    address,
  });
  const balance = gasToken.rawBalance;
  const checkTxValueInBalance = !isTempoChain(chain.serverId);
  let estimateGas = 0;
  if (preExecResult.gas.success) {
    estimateGas = preExecResult.gas.gas_limit || preExecResult.gas.gas_used;
  }
  const { gas: gasRaw, needRatio, gasUsed } = await wallet.getRecommendGas({
    gasUsed: preExecResult.gas.gas_used,
    gas: estimateGas,
    tx,
    chainId: chain.id,
  });
  const gas = new BigNumber(gasRaw);
  let gasLimit = tx.gas || tx.gasLimit;
  let recommendGasLimitRatio = 1;

  if (!gasLimit) {
    const {
      gasLimit: _gasLimit,
      recommendGasLimitRatio: _recommendGasLimitRatio,
    } = await calcGasLimit({
      chain,
      tx,
      gas,
      selectedGas: normalGas,
      nativeTokenBalance: balance,
      explainTx: preExecResult,
      needRatio,
      wallet,
      gasTokenDecimals: gasToken.token.decimals,
      checkTxValueInBalance,
    });
    gasLimit = _gasLimit;
    recommendGasLimitRatio = _recommendGasLimitRatio;
  }

  // calc gasCost
  const gasCost = await explainGas({
    gasUsed,
    gasPrice: normalGas.price,
    chainId: chain.id,
    nativeTokenPrice: preExecResult.native_token.price,
    wallet,
    tx,
    gasLimit,
    account: { ...currentAccount, address },
    gasTokenDecimals: gasToken.token.decimals,
  });

  // check gas errors
  const checkErrors = ignoreGasNotEnoughCheck
    ? []
    : checkGasAndNonce({
        recommendGasLimit: `0x${gas.toString(16)}`,
        recommendNonce,
        gasLimit: Number(gasLimit),
        nonce: Number(recommendNonce || tx.nonce),
        gasExplainResponse: gasCost,
        isSpeedUp: false,
        isCancel: false,
        tx,
        isGnosisAccount: false,
        nativeTokenBalance: balance,
        recommendGasLimitRatio,
        gasTokenDecimals: gasToken.token.decimals,
        gasTokenId: gasToken.token.tokenId,
        checkTxValueInBalance,
      });

  const isGasNotEnough = !isGasLess && checkErrors.some((e) => e.code === 3001);
  const ETH_GAS_USD_LIMIT = process.env.DEBUG
    ? (await Browser.storage.local.get('DEBUG_ETH_GAS_USD_LIMIT'))
        .DEBUG_ETH_GAS_USD_LIMIT || 20
    : 20;
  const OTHER_CHAIN_GAS_USD_LIMIT = process.env.DEBUG
    ? (await Browser.storage.local.get('DEBUG_OTHER_CHAIN_GAS_USD_LIMIT'))
        .DEBUG_OTHER_CHAIN_GAS_USD_LIMIT || 5
    : 5;
  const DEBUG_SIMULATION_FAILED = process.env.DEBUG
    ? (await Browser.storage.local.get('DEBUG_SIMULATION_FAILED'))
        .DEBUG_SIMULATION_FAILED
    : false;

  // generate tx with gas
  const transaction: TxWithTempoExtras<Tx> = {
    from: tx.from,
    to: tx.to,
    data: tx.data,
    nonce: recommendNonce,
    value: tx.value,
    chainId: tx.chainId,
    gas: gasLimit,
    type: (tx as TxWithTempoExtras<Tx>).type,
    calls: (tx as TxWithTempoExtras<Tx>).calls,
    feeToken: (tx as TxWithTempoExtras<Tx>).feeToken,
    feePayer: (tx as TxWithTempoExtras<Tx>).feePayer,
    feePayerSignature: (tx as TxWithTempoExtras<Tx>).feePayerSignature,
    nonceKey: (tx as TxWithTempoExtras<Tx>).nonceKey,
    keyAuthorization: (tx as TxWithTempoExtras<Tx>).keyAuthorization,
    validBefore: (tx as TxWithTempoExtras<Tx>).validBefore,
    validAfter: (tx as TxWithTempoExtras<Tx>).validAfter,
  };

  let failedCode;
  let canUseGasAccount: boolean = false;

  // random simulation failed for test
  if (
    !ignoreSimulationFailed &&
    DEBUG_SIMULATION_FAILED &&
    Math.random() > 0.5
  ) {
    failedCode = FailedCode.SimulationFailed;
  } else if (
    !ignoreSimulationFailed &&
    !preExecResult?.balance_change?.success
  ) {
    failedCode = FailedCode.SimulationFailed;
  } else if (isGasNotEnough) {
    const gasAccount = await wallet.getGasAccountSig();
    if (sig !== gasAccount?.sig) {
      sig = gasAccount?.sig;
    }
    //  native gas not enough check gasAccount
    if (autoUseGasAccount && gasAccount?.sig && gasAccount?.accountId) {
      const gasAccountCanPay = await checkEnoughUseGasAccount({
        gasAccount,
        currentAccountType: currentAccount.type,
        wallet,
        transaction: {
          ...(shouldUseTempoCallsForGasAccount(true)
            ? (toTempoCallsTx(
                {
                  ...transaction,
                  gas: gasLimit,
                  gasPrice: intToHex(normalGas.price),
                },
                { stripTopLevelData: true }
              ) as any)
            : {
                ...transaction,
                gas: gasLimit,
                gasPrice: intToHex(normalGas.price),
              }),
        },
      });
      if (gasAccountCanPay) {
        onUseGasAccount?.();
        canUseGasAccount = true;
      } else {
        failedCode = FailedCode.GasNotEnough;
      }
    } else {
      failedCode = FailedCode.GasNotEnough;
    }
  } else if (
    !ignoreGasCheck &&
    // eth gas > $20
    ((chain.enum === CHAINS_ENUM.ETH &&
      gasCost.gasCostUsd.isGreaterThan(ETH_GAS_USD_LIMIT)) ||
      // other chain gas > $5
      (chain.enum !== CHAINS_ENUM.ETH &&
        gasCost.gasCostUsd.isGreaterThan(OTHER_CHAIN_GAS_USD_LIMIT)))
  ) {
    failedCode = FailedCode.GasTooHigh;
  }

  if (failedCode) {
    throw {
      name: failedCode,
      gasCost,
    };
  }

  const maxPriorityFee =
    +(tx.maxPriorityFeePerGas || '') ||
    calcMaxPriorityFee([], normalGas, chain.id, true);
  const maxFeePerGas =
    tx.maxFeePerGas || tx.gasPrice || intToHex(Math.round(normalGas.price));

  if (support1559) {
    transaction.maxFeePerGas = maxFeePerGas;
    transaction.maxPriorityFeePerGas =
      maxPriorityFee < 0
        ? tx.maxFeePerGas
        : intToHex(Math.round(maxPriorityFee));
  } else {
    (transaction as Tx).gasPrice = maxFeePerGas;
  }

  const shouldUseGasAccountMode = autoUseGasAccount
    ? canUseGasAccount
    : isGasAccount;
  const transactionForSubmit = shouldUseTempoCallsForGasAccount(
    shouldUseGasAccountMode
  )
    ? ({
        ...(toTempoCallsTx(transaction as any, {
          stripTopLevelData: true,
        }) as any),
        feePayer: true,
      } as any)
    : transaction;

  // fetch action data
  const actionData =
    extra?.actionData ||
    (await wallet.openapi.parseTx({
      chainId: chain.serverId,
      tx: shouldUseTempoCallsForGasAccount(shouldUseGasAccountMode)
        ? (toTempoCallsTx(
            {
              ...tx,
              gas: '0x0',
              nonce: recommendNonce || '0x1',
              value: tx.value || '0x0',
              to: tx.to || '',
              type: '0x76',
            },
            { stripTopLevelData: true }
          ) as any)
        : ({
            ...tx,
            gas: '0x0',
            nonce: recommendNonce || '0x1',
            value: tx.value || '0x0',
            to: tx.to || '',
            type: is7702Tx(tx) ? 4 : support1559 ? 2 : undefined,
          } as any),
      origin: session?.origin || '',
      addr: address,
    }));
  const parsed = parseAction({
    type: 'transaction',
    data: actionData.action,
    balanceChange: preExecResult.balance_change,
    tx: shouldUseTempoCallsForGasAccount(shouldUseGasAccountMode)
      ? (toTempoCallsTx(
          {
            ...tx,
            gas: '0x0',
            nonce: recommendNonce || '0x1',
            value: tx.value || '0x0',
            type: '0x76',
          },
          { stripTopLevelData: true }
        ) as any)
      : {
          ...tx,
          gas: '0x0',
          nonce: recommendNonce || '0x1',
          value: tx.value || '0x0',
        },
    preExecVersion: preExecResult.pre_exec_version,
    gasUsed: preExecResult.gas.gas_used,
    sender: tx.from,
  });
  const cexInfo = await getCexInfo(parsed.send?.to || '', wallet);
  const requiredData = await fetchActionRequiredData({
    type: 'transaction',
    actionData: parsed,
    contractCall: actionData.contract_call,
    chainId: chain.serverId,
    sender: address,
    walletProvider: {
      ethRpc: wallet.requestETHRpc,
      hasPrivateKeyInWallet: wallet.hasPrivateKeyInWallet,
      hasAddress: wallet.hasAddress,
      getWhitelist: wallet.getWhitelist,
      isWhitelistEnabled: wallet.isWhitelistEnabled,
      getPendingTxsByNonce: wallet.getPendingTxsByNonce,
      findChain,
      ALIAS_ADDRESS,
    },
    cex: cexInfo,
    tx: {
      ...(shouldUseTempoCallsForGasAccount(shouldUseGasAccountMode)
        ? (toTempoCallsTx(
            {
              ...tx,
              gas: '0x0',
              nonce: recommendNonce || '0x1',
              value: tx.value || '0x0',
              type: '0x76',
            },
            { stripTopLevelData: true }
          ) as any)
        : {
            ...tx,
            gas: '0x0',
            nonce: recommendNonce || '0x1',
            value: tx.value || '0x0',
          }),
    },
    apiProvider: isTestnet(chain.serverId)
      ? ((wallet.fakeTestnetOpenapi as unknown) as any)
      : wallet.openapi,
  });

  await wallet.updateSigningTx(signingTxId, {
    rawTx: {
      nonce: recommendNonce,
    },
    explain: {
      ...preExecResult,
      calcSuccess: !(checkErrors.length > 0),
    },
    action: {
      actionData: parsed,
      requiredData,
    },
  });
  const logId = actionData.log_id;
  const estimateGasCost = {
    gasCostUsd: gasCost.gasCostUsd,
    gasCostAmount: gasCost.gasCostAmount,
    nativeTokenSymbol: preExecResult.native_token.symbol,
    gasPrice: normalGas.price,
    nativeTokenPrice: preExecResult.native_token.price,
  };

  onProgress?.('builded');

  if (process.env.DEBUG) {
    const { DEBUG_MOCK_SUBMIT } = await Browser.storage.local.get(
      'DEBUG_MOCK_SUBMIT'
    );

    if (DEBUG_MOCK_SUBMIT) {
      return {
        txHash: 'mock_hash',
        gasCost: estimateGasCost,
      };
    }
  }

  const handleSendAfter = async () => {
    const statsData = await wallet.getStatsData();

    if (statsData?.signed) {
      const sData: any = {
        type: statsData?.type,
        chainId: statsData?.chainId,
        category: statsData?.category,
        success: statsData?.signedSuccess,
        preExecSuccess: statsData?.preExecSuccess,
        createdBy: statsData?.createdBy,
        source: statsData?.source,
        trigger: statsData?.trigger,
        networkType: statsData?.networkType,
      };
      if (statsData.signMethod) {
        sData.signMethod = statsData.signMethod;
      }
      stats.report('signedTransaction', sData);
    }
    if (statsData?.submit) {
      stats.report('submitTransaction', {
        type: statsData?.type,
        chainId: statsData?.chainId,
        category: statsData?.category,
        success: statsData?.submitSuccess,
        preExecSuccess: statsData?.preExecSuccess,
        createdBy: statsData?.createdBy,
        source: statsData?.source,
        trigger: statsData?.trigger,
        networkType: statsData?.networkType || '',
      });
    }
  };

  wallet.reportStats('signTransaction', {
    type: currentAccount.brandName,
    category: KEYRING_CATEGORY_MAP[currentAccount.type],
    chainId: chain.serverId,
    createdBy: ga ? 'rabby' : 'dapp',
    source: ga?.source || '',
    trigger: ga?.trigger || '',
    networkType: chain?.isTestnet ? 'Custom Network' : 'Integrated Network',
  });

  // submit tx
  let hash = '';
  try {
    hash = await wallet.ethSendTransaction({
      data: {
        $ctx: {
          ga,
        },
        params: [
          {
            ...transactionForSubmit,
            isSpeedUp: (tx as any)?.isSpeedUp,
            isCancel: (tx as any)?.isCancel,
          },
        ],
      },
      session: session || INTERNAL_REQUEST_SESSION,
      approvalRes: {
        ...transactionForSubmit,
        signingTxId,
        logId: logId,
        lowGasDeadline,
        isGasLess,
        isGasAccount: shouldUseGasAccountMode,
        pushType,
        sig,
      },
      pushed: false,
      result: undefined,
      account: account!,
    });
    await handleSendAfter();
  } catch (e) {
    await handleSendAfter();
    const err = new Error(e.message);
    err.name = FailedCode.SubmitTxFailed;
    eventBus.emit(EVENTS.COMMON_HARDWARE.REJECTED, e.message);
    throw err;
  }

  onProgress?.('signed');

  if (waitCompleted) {
    // wait tx completed
    const txCompleted = await new Promise<{ gasUsed: number }>((resolve) => {
      const handler = (res) => {
        if (res?.hash === hash) {
          eventBus.removeEventListener(EVENTS.TX_COMPLETED, handler);
          resolve(res || {});
        }
      };
      eventBus.addEventListener(EVENTS.TX_COMPLETED, handler);
    });

    // calc gas cost
    const gasCostAmount = new BigNumber(txCompleted.gasUsed)
      .times(estimateGasCost.gasPrice)
      .div(1e18);
    const gasCostUsd = new BigNumber(gasCostAmount).times(
      estimateGasCost.nativeTokenPrice
    );

    return {
      txHash: hash,
      preExecResult,
      gasCost: {
        ...estimateGasCost,
        gasCostUsd,
        gasCostAmount,
      },
    };
  } else {
    return {
      txHash: hash,
      preExecResult,
      gasCost: {
        ...estimateGasCost,
      },
    };
  }
};

export const sendTransactionByMiniSignV2 = async ({
  tx,
  chainServerId,
  wallet,
  onProgress,
  lowGasDeadline,
  isGasLess,
  isGasAccount,
  pushType = 'default',
  ga,
  sig,
  session,
  account: _account,
  preExecResult,
}: {
  tx: Tx;
  chainServerId: string;
  wallet: WalletControllerType;
  onProgress?: (status: ProgressStatus) => void;
  lowGasDeadline?: number;
  isGasLess?: boolean;
  isGasAccount?: boolean;
  pushType?: TxPushType;
  ga?: Record<string, any>;
  sig?: string;
  session?: Parameters<typeof wallet.ethSendTransaction>[0]['session'];
  account?: Account;
  preExecResult?: ExplainTxResponse;
  parsedData?: ParsedTransactionActionData;
  requiredData?: ActionRequireData;
}) => {
  const buildTempoTx = (
    rawTx: Tx & Record<string, unknown>,
    opts?: { stripTopLevelData?: boolean; feePayer?: boolean }
  ) =>
    buildTempoTransaction(rawTx as any, {
      stripTopLevelData: opts?.stripTopLevelData ?? true,
      feePayer: opts?.feePayer,
    });
  onProgress?.('building');

  const chain = findChain({
    serverId: chainServerId,
  })!;
  const support1559 = chain.eip['1559'];

  const currentAccount = _account || (await wallet.getCurrentAccount())!;
  const shouldUseTempoCallsForGasAccount =
    !!isGasAccount &&
    isTempoChain(chainServerId) &&
    isTempoBatchSupportedAccountType(currentAccount.type);
  const shouldUseTempoTx = shouldUseTempoTransaction({
    tx: tx as Tx & Record<string, unknown>,
    chainServerId,
    isGasAccount: shouldUseTempoCallsForGasAccount,
    accountType: currentAccount.type,
  });

  const signingTxId = await wallet.addSigningTx(tx);

  let reportGasLevel = 'normal';
  try {
    reportGasLevel = await wallet.getReportGasLevel();
  } catch (error) {
    console.error('getReportGasLevel error', error);
  }

  wallet.reportStats('createTransaction', {
    type: currentAccount.brandName,
    category: KEYRING_CATEGORY_MAP[currentAccount.type],
    chainId: chain.serverId,
    createdBy: ga ? 'rabby' : 'dapp',
    source: ga?.source || '',
    trigger: ga?.trigger || '',
    networkType: chain?.isTestnet ? 'Custom Network' : 'Integrated Network',
    swapUseSlider: ga?.swapUseSlider ?? '',
    gasLevel: reportGasLevel,
  });

  const transaction: TxWithTempoExtras<Tx> = {
    from: tx.from,
    to: tx.to,
    data: tx.data,
    nonce: tx.nonce,
    value: tx.value,
    chainId: tx.chainId,
    gas: tx.gas,
    type: (tx as TxWithTempoExtras<Tx>).type,
    calls: (tx as TxWithTempoExtras<Tx>).calls,
    feeToken: (tx as TxWithTempoExtras<Tx>).feeToken,
    feePayer: (tx as TxWithTempoExtras<Tx>).feePayer,
    feePayerSignature: (tx as TxWithTempoExtras<Tx>).feePayerSignature,
    nonceKey: (tx as TxWithTempoExtras<Tx>).nonceKey,
    keyAuthorization: (tx as TxWithTempoExtras<Tx>).keyAuthorization,
    validBefore: (tx as TxWithTempoExtras<Tx>).validBefore,
    validAfter: (tx as TxWithTempoExtras<Tx>).validAfter,
  };

  const maxPriorityFee = +(tx.maxPriorityFeePerGas || '');
  const maxFeePerGas = tx.maxFeePerGas || tx.gasPrice;

  if (support1559) {
    transaction.maxFeePerGas = maxFeePerGas;
    transaction.maxPriorityFeePerGas =
      maxPriorityFee < 0
        ? tx.maxFeePerGas
        : intToHex(Math.round(maxPriorityFee));
  } else {
    (transaction as Tx).gasPrice = maxFeePerGas;
  }
  const transactionForSubmit = shouldUseTempoTx
    ? ({
        ...(buildTempoTx(transaction as any, {
          stripTopLevelData: true,
          feePayer: shouldUseTempoCallsForGasAccount,
        }) as any),
      } as any)
    : transaction;
  try {
    //for Signature Record
    const actionData = await wallet.openapi.parseTx({
      chainId: chain.serverId,
      tx: shouldUseTempoTx
        ? (buildTempoTx(
            {
              ...tx,
              gas: '0x0',
              nonce: tx.nonce || '0x1',
              value: tx.value || '0x0',
              to: tx.to || '',
            },
            {
              stripTopLevelData: true,
              feePayer: shouldUseTempoCallsForGasAccount,
            }
          ) as any)
        : ({
            ...tx,
            gas: '0x0',
            nonce: tx.nonce || '0x1',
            value: tx.value || '0x0',
            to: tx.to || '',
            type: is7702Tx(tx) ? 4 : support1559 ? 2 : undefined,
          } as any),
      origin: session?.origin || '',
      addr: currentAccount.address,
    });
    const parsed = parseAction({
      type: 'transaction',
      data: actionData.action,
      balanceChange: preExecResult!.balance_change,
      tx: shouldUseTempoTx
        ? (buildTempoTx(
            {
              ...tx,
              gas: '0x0',
              nonce: tx.nonce || '0x1',
              value: tx.value || '0x0',
            },
            {
              stripTopLevelData: true,
              feePayer: shouldUseTempoCallsForGasAccount,
            }
          ) as any)
        : {
            ...tx,
            gas: '0x0',
            nonce: tx.nonce || '0x1',
            value: tx.value || '0x0',
          },
      preExecVersion: preExecResult!.pre_exec_version,
      gasUsed: preExecResult!.gas.gas_used,
      sender: tx.from,
    });
    const cexInfo = await getCexInfo(parsed.send?.to || '', wallet);
    const requiredData = await fetchActionRequiredData({
      type: 'transaction',
      actionData: parsed,
      contractCall: actionData.contract_call,
      chainId: chain.serverId,
      sender: currentAccount.address,
      walletProvider: {
        ethRpc: wallet.requestETHRpc,
        hasPrivateKeyInWallet: wallet.hasPrivateKeyInWallet,
        hasAddress: wallet.hasAddress,
        getWhitelist: wallet.getWhitelist,
        isWhitelistEnabled: wallet.isWhitelistEnabled,
        getPendingTxsByNonce: wallet.getPendingTxsByNonce,
        findChain,
        ALIAS_ADDRESS,
      },
      cex: cexInfo,
      tx: {
        ...(shouldUseTempoTx
          ? (buildTempoTx(
              {
                ...tx,
                gas: '0x0',
                nonce: tx.nonce || '0x1',
                value: tx.value || '0x0',
              },
              {
                stripTopLevelData: true,
                feePayer: shouldUseTempoCallsForGasAccount,
              }
            ) as any)
          : {
              ...tx,
              gas: '0x0',
              nonce: tx.nonce || '0x1',
              value: tx.value || '0x0',
            }),
      },
      apiProvider: isTestnet(chain.serverId)
        ? ((wallet.fakeTestnetOpenapi as unknown) as any)
        : wallet.openapi,
    });

    await wallet.updateSigningTx(signingTxId, {
      rawTx: {
        nonce: tx.nonce,
      },
      explain: {
        ...preExecResult,
        calcSuccess: true,
      },
      action: {
        actionData: parsed,
        requiredData: requiredData,
      },
    });
  } catch (error) {
    await wallet.updateSigningTx(signingTxId, {
      rawTx: {
        nonce: tx.nonce,
      },
    });
  }

  onProgress?.('builded');

  const handleSendAfter = async () => {
    const statsData = await wallet.getStatsData();

    if (statsData?.signed) {
      const sData: any = {
        type: statsData?.type,
        chainId: statsData?.chainId,
        category: statsData?.category,
        success: statsData?.signedSuccess,
        preExecSuccess: statsData?.preExecSuccess,
        createdBy: statsData?.createdBy,
        source: statsData?.source,
        trigger: statsData?.trigger,
        networkType: statsData?.networkType,
      };
      if (statsData.signMethod) {
        sData.signMethod = statsData.signMethod;
      }
      stats.report('signedTransaction', sData);
    }
    if (statsData?.submit) {
      stats.report('submitTransaction', {
        type: statsData?.type,
        chainId: statsData?.chainId,
        category: statsData?.category,
        success: statsData?.submitSuccess,
        preExecSuccess: statsData?.preExecSuccess,
        createdBy: statsData?.createdBy,
        source: statsData?.source,
        trigger: statsData?.trigger,
        networkType: statsData?.networkType || '',
      });
    }
  };

  wallet.reportStats('signTransaction', {
    type: currentAccount.brandName,
    category: KEYRING_CATEGORY_MAP[currentAccount.type],
    chainId: chain.serverId,
    createdBy: ga ? 'rabby' : 'dapp',
    source: ga?.source || '',
    trigger: ga?.trigger || '',
    networkType: chain?.isTestnet ? 'Custom Network' : 'Integrated Network',
  });

  // submit tx
  let hash = '';
  const account = currentAccount;
  try {
    hash = await wallet.ethSendTransaction({
      data: {
        $ctx: {
          ga,
        },
        params: [
          {
            ...transactionForSubmit,
            isSpeedUp: (tx as any)?.isSpeedUp,
            isCancel: (tx as any)?.isCancel,
          },
        ],
      },
      session: session || INTERNAL_REQUEST_SESSION,
      approvalRes: {
        ...transactionForSubmit,
        signingTxId,
        lowGasDeadline,
        isGasLess,
        isGasAccount,
        pushType,
        sig,
      },
      pushed: false,
      result: undefined,
      account: account,
    });
    await handleSendAfter();
  } catch (e) {
    await handleSendAfter();
    const err = new Error(e.message);
    err.name = FailedCode.SubmitTxFailed;
    eventBus.emit(EVENTS.COMMON_HARDWARE.REJECTED, e.message);
    throw err;
  }

  onProgress?.('signed');

  return {
    txHash: hash,
  };
};
