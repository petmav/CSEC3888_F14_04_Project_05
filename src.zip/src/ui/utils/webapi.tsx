import React from 'react';
import browser, { Tabs, Windows } from 'webextension-polyfill';
import { t } from 'i18next';
import { Button } from 'antd';
import { getUITypeName, WalletController, WalletControllerType } from './index';
import { getOriginFromUrl } from '@/utils';
import Modal from '../component/Modal';
import { ReactComponent as ExternalLinkAlert } from 'ui/assets/component/external-link-alert.svg';
import { getCurrentTab } from './currentTab';

export { getCurrentTab } from './currentTab';

export const getCurrentConnectSite = async (
  wallet: WalletController | WalletControllerType
) => {
  const tab = await getCurrentTab();
  if (tab?.id == null || !tab.url) return null;

  return (wallet as WalletControllerType).getCurrentConnectedSite(
    tab.id,
    getOriginFromUrl(tab.url)
  );
};

export const openInTab = async (
  url?: string,
  needClose = true
): Promise<Tabs.Tab> => {
  const tab = await browser.tabs.create({
    active: true,
    url,
  });

  const isDesktop = getUITypeName() === 'desktop';
  if (needClose && !isDesktop) window.close();

  return tab;
};

export const getCurrentWindow = async (): Promise<number | undefined> => {
  const { id } = await browser.windows.getCurrent({
    windowTypes: ['popup'],
  } as Windows.GetInfo);

  return id;
};

export const openInternalPageInTab = (
  path: string,
  useWebapi = true,
  needClose = true
) => {
  if (useWebapi) {
    openInTab(`./index.html#/${path}`, needClose);
  } else {
    window.open(`./index.html#/${path}`);
  }
};

export const TRUSTED_URLS = {
  chromeStoreUrl:
    'https://chromewebstore.google.com/detail/rabby-wallet/acmacodkjbdgmoleebolmdjonilkdbch',
  chromeStoreReviewsUrl:
    'https://chromewebstore.google.com/detail/rabby-wallet/acmacodkjbdgmoleebolmdjonilkdbch/reviews',
  // // notice, only logged google user can access this page
  // chromeStoreMyReviewUrl:
  //   'https://chromewebstore.google.com/detail/rabby-wallet/acmacodkjbdgmoleebolmdjonilkdbch/reviews/my-review',
};
export const openTrustedExternalWebsiteInTab = async (
  type: keyof typeof TRUSTED_URLS,
  needClose = false
) => {
  const url = TRUSTED_URLS[type];

  await browser.tabs.create({
    active: true,
    url,
  });
  if (needClose) window.close();
};

export const openExternalWebsiteInTab = async (
  url?: string,
  needClose = true
) => {
  return new Promise((resolve, reject) => {
    const modal = Modal.info({
      closable: true,
      className: 'external-link-alert-modal',
      content: (
        <div>
          <div className="flex justify-center mb-16">
            <ExternalLinkAlert className="w-[52px]" />
          </div>
          <h1 className="text-r-neutral-title1 text-center mb-8">
            {t('component.OpenExternalWebsiteModal.title')}
          </h1>
          <p className="text-r-neutral-body text-center text-15 mb-[52px]">
            {t('component.OpenExternalWebsiteModal.content')}
          </p>
          <div className="footer">
            <Button
              type="primary"
              block
              className="h-40 text-15 font-medium"
              onClick={async () => {
                const tab = await browser.tabs.create({
                  active: true,
                  url,
                });
                if (needClose) window.close();
                resolve(tab);
                modal.destroy();
              }}
            >
              {t('component.OpenExternalWebsiteModal.button')}
            </Button>
          </div>
        </div>
      ),
      onCancel() {
        reject('user cancel');
      },
    });
  });
};
