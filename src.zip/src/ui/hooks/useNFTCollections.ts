import { NFT_SYNC_SCENE, CACHE_VALID_DURATION } from '@/db/constants';
import { nftDbService } from '@/db/services/nftDbService';
import { syncDbService } from '@/db/services/syncDbService';
import { isFullVersionAccountType } from '@/utils/account';
import { CollectionList } from '@rabby-wallet/rabby-api/dist/types';
import { useCallback, useEffect, useRef } from 'react';
import { isSameAddress } from '../utils';
import { useSafeState } from '../utils/safeState';
import { useWallet } from '../utils/WalletContext';
import { commonCollectionsFilter } from '../utils/portfolio/collections';

const shouldUseNftCollectionsDbCache = ({
  forceRefresh = false,
  updatedAt,
  now = Date.now(),
}: {
  forceRefresh?: boolean;
  updatedAt: number;
  now?: number;
}) => !forceRefresh && updatedAt > now - CACHE_VALID_DURATION;

interface UseNFTCollectionsOptions {
  preferCacheOnExists?: boolean;
  visible?: boolean;
}

export const useNFTCollections = (
  userAddr: string | undefined,
  options?: UseNFTCollectionsOptions
) => {
  const { preferCacheOnExists = false, visible = true } = options || {};
  const wallet = useWallet();
  const abortProcess = useRef<AbortController>();
  const userAddrRef = useRef('');

  const [collections, setCollections] = useSafeState<CollectionList[]>([]);
  const [hasValue, setHasValue] = useSafeState(false);
  const [isLoading, setLoading] = useSafeState(true);

  const applyCollections = useCallback(
    (nextCollections: CollectionList[]) => {
      setCollections(nextCollections);
      setHasValue(nextCollections.length > 0);
    },
    [setCollections, setHasValue]
  );

  const loadProcess = useCallback(
    async ({ forceRefresh = false } = {}) => {
      if (!userAddr) {
        applyCollections([]);
        setLoading(false);
        return;
      }

      abortProcess.current?.abort();
      const currentAbort = new AbortController();
      abortProcess.current = currentAbort;

      setLoading(true);

      let currentCollections: CollectionList[] = [];
      const matchedAccount = await wallet.getAccountByAddress(userAddr);
      const shouldPersistNFTCache = matchedAccount
        ? isFullVersionAccountType(matchedAccount as any)
        : false;

      try {
        if (shouldPersistNFTCache) {
          currentCollections = await nftDbService.queryCollections(userAddr);

          if (currentAbort.signal.aborted) {
            setLoading(false);
            return;
          }

          const updatedAt =
            (await syncDbService.getUpdatedAt({
              address: userAddr,
              scene: NFT_SYNC_SCENE,
            })) || 0;

          if (
            preferCacheOnExists &&
            currentCollections.length > 0 &&
            !forceRefresh
          ) {
            applyCollections(currentCollections);
            setLoading(false);
            return;
          }

          const shouldUseDbCache = shouldUseNftCollectionsDbCache({
            forceRefresh,
            updatedAt,
          });

          if (shouldUseDbCache) {
            applyCollections(currentCollections);
            setLoading(false);
            return;
          }

          if (currentCollections.length) {
            applyCollections(currentCollections);
            setLoading(false);
          }
        } else {
          await Promise.all([
            nftDbService.deleteForAddress(userAddr),
            syncDbService.deleteSceneForAddress({
              address: userAddr,
              scene: NFT_SYNC_SCENE,
            }),
          ]);
        }
      } catch (error) {
        // ignore Dexie failures and continue with the remote snapshot
      }

      try {
        const remoteCurrentCollections = await wallet.openapi.collectionList({
          id: userAddr,
          isAll: true,
        });
        currentCollections = commonCollectionsFilter(remoteCurrentCollections);

        if (currentAbort.signal.aborted) {
          setLoading(false);
          return;
        }

        applyCollections(currentCollections);

        if (shouldPersistNFTCache) {
          await nftDbService.replaceAddressCollections(
            userAddr,
            currentCollections
          );
          await syncDbService.setUpdatedAt({
            address: userAddr,
            scene: NFT_SYNC_SCENE,
            updatedAt: Date.now(),
          });
        }
      } catch (error) {
        // keep stale data if the remote snapshot fails
      } finally {
        if (!currentAbort.signal.aborted) {
          setLoading(false);
        }
      }
    },
    [applyCollections, preferCacheOnExists, setLoading, userAddr, wallet]
  );

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | null = null;

    if (userAddr && !isSameAddress(userAddr, userAddrRef.current)) {
      applyCollections([]);
    }

    if (userAddr) {
      timer = setTimeout(() => {
        if (!isSameAddress(userAddr, userAddrRef.current) && visible) {
          abortProcess.current?.abort();
          userAddrRef.current = userAddr;
          loadProcess();
        }
      });
    } else {
      applyCollections([]);
      setLoading(false);
    }

    return () => {
      abortProcess.current?.abort();
      if (timer) {
        clearTimeout(timer);
      }
    };
  }, [applyCollections, loadProcess, setLoading, userAddr, visible]);

  useEffect(() => {
    return () => {
      abortProcess.current?.abort();
    };
  }, []);

  const refresh = useCallback(async () => {
    await loadProcess({ forceRefresh: true });
  }, [loadProcess]);

  return {
    collections: collections || [],
    hasValue: !!hasValue,
    isLoading: !!isLoading,
    refresh,
  };
};
