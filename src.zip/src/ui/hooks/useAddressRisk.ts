/* eslint "react-hooks/exhaustive-deps": ["error"] */
/* eslint-enable react-hooks/exhaustive-deps */
import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useTranslation } from 'react-i18next';
import PQueue from 'p-queue';
import { isValidAddress } from '@ethereumjs/util';
import { AddrDescResponse } from '@rabby-wallet/rabby-api/dist/types';

import { useRabbyDispatch, useRabbySelector } from '../store';
import { IExchange } from '../component/CexSelect';

import { isSameAddress, useWallet } from '../utils';
import { KEYRING_CLASS } from 'consts';
import { useDebouncedValue } from './useDebounceValue';
import { useExchangeStore } from '../state/exchange';
import type { Verdict } from '@/utils/redbelly/verdict';
import { recipientFamiliarity } from '@/utils/redbelly/familiarity';

const queue = new PQueue({ intervalCap: 5, concurrency: 5, interval: 1000 });

const waitQueueFinished = (q: PQueue) => {
  return new Promise((resolve) => {
    q.on('empty', () => {
      if (q.pending <= 0) {
        resolve(null);
      }
    });
  });
};

export const enum RiskType {
  NEVER_SEND = 1,
  SCAM_ADDRESS = 2,
  CONTRACT_ADDRESS = 3,
  CEX_NO_DEPOSIT = 4,

  FORBIDDEN_TIP = 5,
  /** Redbelly recipient is confirmed not KYC registered. */
  REDBELLY_NOT_VERIFIED = 6,
  /** The Redbelly check could not run; silence must not read as safe. */
  REDBELLY_UNKNOWN = 7,
  /** Imitates an address the user has paid before (address poisoning). */
  REDBELLY_LOOKALIKE = 8,
}

const riskTypePriority = {
  [RiskType.CEX_NO_DEPOSIT]: 10e-1,
  [RiskType.NEVER_SEND]: 10,
  [RiskType.CONTRACT_ADDRESS]: 10e1,
  [RiskType.SCAM_ADDRESS]: 10e3,
  [RiskType.FORBIDDEN_TIP]: 10e4,
  [RiskType.REDBELLY_NOT_VERIFIED]: 10e5,
  [RiskType.REDBELLY_UNKNOWN]: 10e2,
  [RiskType.REDBELLY_LOOKALIKE]: 10e4 * 5,
};

export function sortRisksDesc(a: { type: RiskType }, b: { type: RiskType }) {
  return (
    riskTypePriority[b.type as keyof typeof riskTypePriority] -
    riskTypePriority[a.type as keyof typeof riskTypePriority]
  );
}

export type RiskItem = { type: RiskType; value: string };
type ForBiddenCheckParams = {
  user_addr: string;
  id?: string;
  chain_id?: string;
  to_addr: string;
};
export const useAddressRisks = (options: {
  toAddress: string;
  fromAddress?: string;
  forbiddenCheck?: ForBiddenCheckParams;
  onLoadFinished?: (/* ctx: { risks: Array<RiskItem> } */) => void;
  editCex?: IExchange | null;
  scene?: 'send-poly' | 'send-nft' | 'send-token';
  /**
   * The send is on a Redbelly network. DeBank has no Redbelly transfer
   * history, so the "not sent in 180 days" check would fire on every send and
   * mean nothing. It is skipped and the Redbelly verdict is used instead.
   */
  isRedbelly?: boolean;
  /** Redbelly KYC verdict for `toAddress`, or null while it is pending. */
  redbellyVerdict?: Verdict | null;
}) => {
  const {
    toAddress,
    fromAddress,
    forbiddenCheck: input_forbiddenCheck,
    editCex,
    onLoadFinished,
    scene = 'send-poly',
    isRedbelly = false,
    redbellyVerdict = null,
  } = options || {};

  const { t } = useTranslation();
  const wallet = useWallet();
  const dispatch = useRabbyDispatch();

  const accountsList = useRabbySelector(
    (state) => state.accountToDisplay.accountsList
  );
  const exchanges = useExchangeStore((state) => state.exchanges);

  const [addressDesc, setAddressDesc] = useState<
    AddrDescResponse['desc'] | undefined
  >();
  const [forbiddenTip, setForbiddenTip] = useState<string>('');
  const [loadingAddrDesc, setLoadingAddrDesc] = useState(true);
  const [hasNoSent, setHasNoSent] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [loadingHasTransfer, setLoadingHasTransfer] = useState(true);

  // Redbelly has no DeBank transfer history, so "never sent" and the
  // lookalike check come from the wallet's own data instead (accounts,
  // contacts, past payees). Read once per sender, not per keystroke.
  const [redbellyKnown, setRedbellyKnown] = useState<{
    addresses: string[];
    complete: boolean;
  } | null>(null);
  useEffect(() => {
    if (!isRedbelly) {
      setRedbellyKnown(null);
      return;
    }
    let cancelled = false;
    setRedbellyKnown(null);
    wallet
      .getRedbellyKnownAddresses(fromAddress || '')
      .catch((error) => {
        console.error('[redbelly] known addresses failed', error);
        return { addresses: [] as string[], complete: false };
      })
      .then((list) => {
        if (!cancelled) {
          setRedbellyKnown(list);
        }
      });
    return () => {
      cancelled = true;
    };
  }, [isRedbelly, fromAddress, wallet]);
  const redbellyFamiliarity = useMemo(
    () =>
      isRedbelly && redbellyKnown && isValidAddress(toAddress)
        ? recipientFamiliarity(toAddress, redbellyKnown.addresses)
        : null,
    [isRedbelly, redbellyKnown, toAddress]
  );

  const risks = useMemo(() => {
    const isContract = Object.keys(addressDesc?.contract || {}).length > 0;
    const isSafeAddress = Object.keys(addressDesc?.contract || {}).some(
      (key) => {
        const contract = addressDesc?.contract?.[key];
        return !!contract?.multisig;
      }
    );
    return [
      forbiddenTip
        ? {
            type: RiskType.FORBIDDEN_TIP,
            value: forbiddenTip,
          }
        : null,
      addressDesc?.cex?.id && !addressDesc.cex.is_deposit
        ? {
            type: RiskType.CEX_NO_DEPOSIT,
            value:
              scene === 'send-poly'
                ? t('page.sendPoly.riskAlert.riskType.risks.dexNoDeposite')
                : t(
                    'page.selectToAddress.riskAlert.riskType.risks.dexNoDeposite'
                  ),
          }
        : null,
      addressDesc?.is_danger || addressDesc?.is_scam
        ? {
            type: RiskType.SCAM_ADDRESS,
            value:
              scene === 'send-poly'
                ? t('page.sendPoly.riskAlert.riskType.risks.scamAddress')
                : t(
                    'page.selectToAddress.riskAlert.riskType.risks.scamAddress'
                  ),
          }
        : null,
      isContract && !isSafeAddress
        ? {
            type: RiskType.CONTRACT_ADDRESS,
            value:
              scene === 'send-poly'
                ? t('page.sendPoly.riskAlert.riskType.risks.contractAddress')
                : t(
                    'page.selectToAddress.riskAlert.riskType.risks.contractAddress'
                  ),
          }
        : null,
      isRedbelly && redbellyVerdict === 'NOT_REGISTERED'
        ? {
            type: RiskType.REDBELLY_NOT_VERIFIED,
            value: t('page.sendToken.redbelly.notVerified'),
          }
        : null,
      isRedbelly && redbellyVerdict === 'UNKNOWN'
        ? {
            type: RiskType.REDBELLY_UNKNOWN,
            value: t('page.sendToken.redbelly.unknown'),
          }
        : null,
      redbellyFamiliarity?.kind === 'lookalike'
        ? {
            type: RiskType.REDBELLY_LOOKALIKE,
            value: t('page.sendToken.redbelly.lookalike', {
              address: redbellyFamiliarity.similarTo,
            }),
          }
        : null,
      // "Never sent" only from a complete history; otherwise it is a guess.
      (
        isRedbelly
          ? redbellyFamiliarity?.kind === 'new' && !!redbellyKnown?.complete
          : hasNoSent
      )
        ? {
            type: RiskType.NEVER_SEND,
            value:
              scene === 'send-poly'
                ? t('page.sendPoly.riskAlert.riskType.risks.noSend')
                : t('page.selectToAddress.riskAlert.riskType.risks.noSend'),
          }
        : null,
    ].filter((i) => !!i) as { type: RiskType; value: string }[];
  }, [
    forbiddenTip,
    scene,
    addressDesc,
    hasNoSent,
    isRedbelly,
    redbellyVerdict,
    redbellyFamiliarity,
    redbellyKnown,
    t,
  ]);

  const myTop10AccountList = useMemo(
    () =>
      accountsList
        .filter(
          (e) =>
            !(<string[]>[
              KEYRING_CLASS.WATCH,
              KEYRING_CLASS.GNOSIS,
              KEYRING_CLASS.WALLETCONNECT,
              KEYRING_CLASS.CoboArgus,
            ]).includes(e.type)
        )
        .sort((a, b) => b.balance - a.balance)
        .slice(0, 10),
    [accountsList]
  );

  const caredAddresses = useMemo(() => {
    if (fromAddress) return [fromAddress];

    return myTop10AccountList.map((acc) => acc.address);
  }, [fromAddress, myTop10AccountList]);

  useEffect(() => {
    if (!isValidAddress(toAddress)) {
      return;
    }
    dispatch.accountToDisplay.getAllAccountsToDisplay();
  }, [toAddress, dispatch.accountToDisplay]);

  useLayoutEffect(() => {
    if (toAddress) {
      setAddressDesc(undefined);
      setLoadingAddrDesc(true);
      setHasNoSent(false);
      setHasError(false);
      setLoadingHasTransfer(true);
    }
  }, [toAddress]);

  useEffect(() => {
    (async () => {
      if (!isValidAddress(toAddress)) {
        return;
      }
      setLoadingAddrDesc(true);
      try {
        const addrDescRes = await wallet.openapi.addrDesc(toAddress);
        const cexId = await wallet.getCexId(toAddress);
        if (addrDescRes) {
          if (cexId) {
            const localCexInfo = exchanges.find(
              (e) => e.id.toLowerCase() === cexId?.toLowerCase()
            );
            if (localCexInfo) {
              addrDescRes.desc.cex = {
                id: localCexInfo?.id || '',
                name: localCexInfo?.name || '',
                logo_url: localCexInfo?.logo || '',
                is_deposit: true,
              };
            }
          }
          if (editCex) {
            addrDescRes.desc.cex = {
              id: editCex?.id || '',
              name: editCex?.name || '',
              logo_url: editCex?.logo || '',
              is_deposit: true,
            };
          }
          setAddressDesc(addrDescRes.desc);
        }
      } catch (error) {
        /* empty */
      } finally {
        setLoadingAddrDesc(false);
      }
    })();
  }, [toAddress, dispatch, editCex, exchanges, wallet]);

  const memoForbiddenCheck = useMemo(() => {
    return {
      chain_id: input_forbiddenCheck?.chain_id,
      id: input_forbiddenCheck?.id,
      user_addr: input_forbiddenCheck?.user_addr,
      to_addr: input_forbiddenCheck?.to_addr,
    };
  }, [
    input_forbiddenCheck?.chain_id,
    input_forbiddenCheck?.id,
    input_forbiddenCheck?.user_addr,
    input_forbiddenCheck?.to_addr,
  ]);
  const forbiddenCheck = useDebouncedValue(memoForbiddenCheck, 300);

  const reqForbiddenTip = useCallback(async () => {
    const allValuesSet =
      forbiddenCheck?.chain_id &&
      forbiddenCheck?.to_addr &&
      forbiddenCheck?.user_addr &&
      forbiddenCheck?.id;
    if (allValuesSet) {
      await wallet.openapi
        .checkTokenDepositForbidden({
          chain_id: forbiddenCheck?.chain_id || 'eth',
          to_addr: forbiddenCheck?.to_addr || '',
          user_addr: forbiddenCheck?.user_addr || '',
          id: forbiddenCheck?.id || '',
        })
        .then((res) => {
          setForbiddenTip(res?.msg || '');
        })
        .catch((error) => {
          console.error('checkTokenDepositForbidden error', error);
          setForbiddenTip('');
        });
    } else {
      setForbiddenTip('');
    }
  }, [
    wallet,
    forbiddenCheck?.chain_id,
    forbiddenCheck?.to_addr,
    forbiddenCheck?.user_addr,
    forbiddenCheck?.id,
  ]);

  useEffect(() => {
    reqForbiddenTip();
  }, [reqForbiddenTip]);

  const riskGetRef = useRef({
    requestKey: '',
    controller: null as AbortController | null,
  });
  useEffect(() => {
    if (isRedbelly) {
      // No DeBank transfer history for Redbelly: nothing to wait for.
      riskGetRef.current.requestKey = '';
      riskGetRef.current.controller?.abort();
      riskGetRef.current.controller = null;
      queue.clear();
      setHasNoSent(false);
      setHasError(false);
      setLoadingHasTransfer(false);
      // Same reset the transfer check does, so an "I understand" tick given
      // for one recipient never carries over to the next.
      onLoadFinished?.();
      return;
    }
    if (!caredAddresses.length || !isValidAddress(toAddress)) {
      riskGetRef.current.requestKey = '';
      if (riskGetRef.current.controller) {
        riskGetRef.current.controller.abort();
        riskGetRef.current.controller = null;
      }
      queue.clear();
      return;
    }

    const caredAddressesKey = caredAddresses
      .slice()
      .sort()
      .map((addr) => addr.toLowerCase())
      .join(',');
    const requestKey = `${toAddress.toLowerCase()}|${caredAddressesKey}`;

    if (riskGetRef.current.requestKey === requestKey) {
      return;
    }

    riskGetRef.current.requestKey = requestKey;
    const prevController = riskGetRef.current.controller;
    if (prevController) prevController.abort();

    riskGetRef.current.controller = new AbortController();
    const currentController = riskGetRef.current.controller;
    (async () => {
      setLoadingHasTransfer(true);
      setHasError(false);
      let hasSent = false;
      let hasError = false;
      try {
        const hasAborted = (resolveFunc: any) => {
          if (currentController.signal.aborted) {
            resolveFunc();
            queue.clear();
            return true;
          }
        };
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => reject(new Error('timeout')), 3000);
        });
        const checkTransferPromise = new Promise<void>((resolve) => {
          caredAddresses.forEach((addr) => {
            if (hasAborted(resolve)) return;
            if (isSameAddress(addr, toAddress)) return;
            queue.add(async () => {
              try {
                if (hasAborted(resolve)) return;
                if (hasSent || hasError) return;
                const res = await wallet.openapi.hasTransferAllChain(
                  addr,
                  toAddress
                );
                if (res?.has_transfer) {
                  hasSent = true;
                  queue.clear();
                  resolve();
                }
              } catch (error) {
                console.error('has_transfer fetch error', error);
                hasError = true;
                queue.clear();
                resolve();
              }
            });
          });
          waitQueueFinished(queue).then(() => resolve());
        });

        await Promise.race([checkTransferPromise, timeoutPromise]);
        setHasNoSent(!hasSent);
        setHasError(hasError);
      } catch (error) {
        console.error('check transfer timeout or error', error);
        setHasError(true);
        setHasNoSent(true);
        queue.clear();
      } finally {
        onLoadFinished?.();
        setLoadingHasTransfer(false);
      }
    })();
  }, [toAddress, caredAddresses, onLoadFinished, wallet, isRedbelly]);

  return {
    risks,
    addressDesc,
    hasNoSent,
    loading:
      loadingHasTransfer ||
      loadingAddrDesc ||
      // A verdict still in flight must not let the user submit unwarned.
      (isRedbelly &&
        isValidAddress(toAddress) &&
        (redbellyVerdict === null || redbellyKnown === null)),
    loadingAddrDesc,
    loadingHasTransfer,
    hasNotRisk:
      !risks.length && !loadingHasTransfer && !loadingAddrDesc && !hasError,
  };
};
