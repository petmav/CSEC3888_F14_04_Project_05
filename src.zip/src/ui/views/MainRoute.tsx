import React, { useEffect } from 'react';
import { Switch, Route } from 'react-router-dom';
import { PrivateRoute } from 'ui/component';
import Welcome from './Welcome';
import NoAddress from './NoAddress';
import CreatePassword from './CreatePassword';
import ImportMode from './ImportMode';
import ImportPrivateKey from './ImportPrivateKey';
import ImportJson from './ImportJson';
import ImportWatchAddress from './ImportWatchAddress';
import SelectAddress from './SelectAddress';
import ImportSuccess from './ImportSuccess';
import ImportGnosis from './ImportGnosisAddress';
import ConnectLedger from './ImportHardware/LedgerConnect';
import ConnectTrezor from './ImportHardware/TrezorConnect';
import ConnectOneKey from './ImportHardware/OneKeyConnect';
import ConnectedSites from './ConnectedSites';
import Approval from './Approval';
import TokenApproval from './TokenApproval';
import NFTApproval from './NFTApproval';
import AddAddress from './AddAddress';
import ChainList from './ChainList';
import AddressManagement from './AddressManagement';
import SwitchLang from './SwitchLang';
import Activities from './Activities';
import { HistoryPage } from './History';
import PerpsSingleCoin from './Perps/screen/SingleCoin';
import { HistoryPage as PerpsHistoryPage } from './Perps/screen/HistoryPage';
import ExploreMore from './Perps/screen/ExploreMore';
import Staking from './Staking';
import StakingDetail from './Staking/Detail';
import AdvancedSettings from './AdvanceSettings';
import RequestPermission from './RequestPermission';
import SendToken from './SendToken';
import SendNFT from './SendNFT';
import Receive from './Receive/index';
import WalletConnectTemplate from './WalletConnect';
import AddressDetail from './AddressDetail';
import AddressBackupMnemonics from './AddressBackup/Mnemonics';
import AddressBackupPrivateKey from './AddressBackup/PrivateKey';
import Swap from './Swap';
import { getUiType, useWallet } from '../utils';
import CustomRPC from './CustomRPC';
import { ImportMyMetaMaskAccount } from './ImportMyMetaMaskAccount';
import { matomoRequestEvent } from '@/utils/matomo-request';
import { CommonPopup } from './CommonPopup';
import ManageAddress from './ManageAddress';
import { NFTView } from './NFTView';
import { QRCodeConnect } from './ImportHardware/QRCodeConnect';
import { KeystoneConnect } from './ImportHardware/KeystoneConnect';
import { ImportCoboArgus } from './ImportCoboArgus/ImportCoboArgus';
import { ImportCoinbase } from './ImportCoinbase/ImportCoinbase';
import { DappSearchPage } from './DappSearch';
import RabbyPoints from './RabbyPoints';
import { ImKeyConnect } from './ImportHardware/ImKeyConnect';
import InputMnemonics from './ImportMnemonics/InputMnemonics';
import CreateMnemonics from './CreateMnemonics';
import ImportHardware from './ImportHardware';
import { CustomTestnet } from './CustomTestnet';
import { AddFromCurrentSeedPhrase } from './AddFromCurrentSeedPhrase';
import { AddNewAddress } from './AddAddress/AddNewAddress';
import { AddMoreAddressesFromSeedPhrase } from './AddAddress/AddMoreAddressesFromSeedPhrase';
import { CreateAddressSuccess } from './AddAddress/CreateAddressSuccess';
import ImportAddressSuccess from './AddAddress/ImportAddressSuccess';
import { HardwareWallets } from './AddAddress/HardwareWallets';
import BulkImportPrivateKey from './AddAddress/BulkImportPrivateKey';
import ImportKeyOrSeed from './AddAddress/ImportKeyOrSeed';
import { InstitutionalWallets } from './AddAddress/InstitutionalWallets';
import { Ecology } from './Ecology';
import { Bridge } from './Bridge';
import { GasAccount } from './GasAccount';
import { GnosisQueue } from './GnosisQueue';
import Perps from './Perps/screen/home';
import { Guide } from './NewUserImport/Guide';
import { CreateSeedPhrase } from './NewUserImport/CreateSeedPhrase';
import { NewUserSetPassword } from './NewUserImport/SetPassword';
import { NewUserImportGnosisAddress } from './NewUserImport/ImportGnosisAddress';
import { NewUserImportLedger } from './NewUserImport/ImportLedger';
import { NewUserImportImKey } from './NewUserImport/ImportImKey';
import { NewUserImportKeystone } from './NewUserImport/ImportKeystone';
import { NewUserImportOneKey } from './NewUserImport/ImportOnekey';
import { BackupSeedPhrase } from './NewUserImport/BackupSeedPhrase';
import { ImportOrCreatedSuccess } from './NewUserImport/Success';
import { ReadyToUse } from './NewUserImport/ReadyToUse';
import { NewUserImportHardware } from './NewUserImport/ImportHardWare';
import { DARK_MODE_TYPE, KEYRING_CLASS } from '@/constant';
import {
  MetamaskModeDappsGuide,
  MetamaskModeDappsList,
} from './MetamaskModeDapps';
import { NewUserSelectAddress } from './NewUserImport/SelectAddress';
import { ga4 } from '@/utils/ga4';
import { ConnectApproval } from './Approval/components/Connect/SelectWalletApproval';
import { SyncToMobile } from '../utils/SyncToMobile/SyncToMobile';
import dayjs from 'dayjs';
import { PreferenceStore } from '@/background/service/preference';
import WhitelistInput from './WhitelistInput';
import { PortalHost } from '../component/PortalHost';
import {
  GlobalSignerPortal,
  GlobalTypedDataSignerPortal,
} from '../component/MiniSignV2/components';
import SelectToAddress from './SelectToAddress';
import { ImportWalletType } from './NewUserImport/ImportWalletType';
import { ImportHardwareList } from './NewUserImport/importHardwareList';
import { ImportSeedOrKey } from './NewUserImport/ImportSeedOrKey';
import { BiometricUnlockSetup } from './BiometricUnlockSetup';
import { ManageApprovals } from './ManageApprovals';
import { ManageBatchRevokeApprovals } from './ManageBatchApprovals';
import { shouldReportUserBehaviorData } from '@/utils/user-data-tracking';

declare global {
  interface Window {
    _paq: any;
  }
}

const LogPageView = () => {
  const path = window.location.hash.replace(/#/, '');

  useEffect(() => {
    ga4.firePageViewEvent({
      pageLocation: path,
    });

    const trackMatomoPageView = async () => {
      if (!window._paq || !(await shouldReportUserBehaviorData())) {
        return;
      }

      window._paq.push(['setCustomUrl', path]);
      window._paq.push(['trackPageView']);
    };

    trackMatomoPageView();
  }, [path]);

  return null;
};

const Main = () => {
  const wallet = useWallet();

  useEffect(() => {
    (async () => {
      const UIType = getUiType();
      if (UIType.isNotification || UIType.isPop) {
        const hasOtherProvider = await wallet.getHasOtherProvider();
        matomoRequestEvent({
          category: 'User',
          action: 'active',
          label: UIType.isPop
            ? `popup|${hasOtherProvider ? 'hasMetaMask' : 'noMetaMask'}`
            : `request|${hasOtherProvider ? 'hasMetaMask' : 'noMetaMask'}`,
        });

        ga4.fireEvent(
          UIType.isPop
            ? `Popup_${hasOtherProvider ? 'HasMM' : 'NoMM'}`
            : `Request_${hasOtherProvider ? 'HasMM' : 'NoMM'}`,
          {
            event_category: 'User Active',
          }
        );
        const preference: PreferenceStore = await wallet.getPreference();
        if (
          dayjs(preference.ga4EventTime || 0)
            .utc()
            .isSame(dayjs().utc(), 'day')
        ) {
          return;
        }
        await wallet.trackGasAccountActiveStatusOncePerDay();

        ga4.fireEvent(
          `ThemeMode_${
            preference.themeMode === DARK_MODE_TYPE.dark ? 'Dark' : 'Light'
          }`,
          {
            event_category: 'Settings Snapshot',
          }
        );
        ga4.fireEvent(
          `DappAccount_${preference.isEnabledDappAccount ? 'On' : 'Off'}`,
          {
            event_category: 'Settings Snapshot',
          }
        );

        const isEnabledWhiteList = await wallet.isWhitelistEnabled();
        ga4.fireEvent(`Whitelist_${isEnabledWhiteList ? 'On' : 'Off'}`, {
          event_category: 'Settings Snapshot',
        });

        ga4.fireEvent(
          `PwdForNonWhitelistedTx_${
            preference.isEnabledPwdForNonWhitelistedTx ? 'On' : 'Off'
          }`,
          {
            event_category: 'Settings Snapshot',
          }
        );

        const isBiometricsEnabled = preference.biometricUnlockEnabled;
        ga4.fireEvent(
          `Unlock_Biometrics_${isBiometricsEnabled ? 'On' : 'Off'}`,
          {
            event_category: 'Settings Snapshot',
          }
        );

        ga4.fireEvent(
          `PerpsFloating_${preference.perpsWidgetEnabled ? 'On' : 'Off'}`,
          {
            event_category: 'Settings Snapshot',
          }
        );
        wallet.updateGa4EventTime(Date.now());
      }
    })();
  }, []);

  return (
    <>
      <Route path="/" component={LogPageView} />
      <Switch>
        <Route exact path="/welcome">
          <Welcome />
        </Route>

        {/* todo remove */}
        <Route exact path="/sync">
          <SyncToMobile />
        </Route>

        <Route exact path="/new-user/guide">
          <Guide />
        </Route>

        <Route exact path="/new-user/import-wallet-type">
          <ImportWalletType />
        </Route>

        <Route exact path="/new-user/import-hardware-list">
          <ImportHardwareList />
        </Route>

        <Route exact path="/new-user/import/gnosis-address">
          <NewUserImportGnosisAddress />
        </Route>

        <Route exact path="/new-user/import/seed-or-key">
          <ImportSeedOrKey />
        </Route>

        <Route
          exact
          path={`/new-user/import/hardware/${KEYRING_CLASS.HARDWARE.LEDGER}`}
        >
          <NewUserImportLedger />
        </Route>

        <Route
          exact
          path={`/new-user/import/hardware/${KEYRING_CLASS.HARDWARE.IMKEY}`}
        >
          <NewUserImportImKey />
        </Route>

        <Route
          exact
          path={`/new-user/import/hardware/${KEYRING_CLASS.HARDWARE.KEYSTONE}`}
        >
          <NewUserImportKeystone />
        </Route>

        <Route
          exact
          path={`/new-user/import/hardware/${KEYRING_CLASS.HARDWARE.ONEKEY}`}
        >
          <NewUserImportOneKey />
        </Route>

        <Route exact path="/new-user/import/hardware/:type">
          <NewUserImportHardware />
        </Route>

        <Route exact path="/new-user/import/:type/set-password">
          <NewUserSetPassword />
        </Route>

        <Route exact path="/new-user/create-seed-phrase">
          <CreateSeedPhrase />
        </Route>

        <Route exact path="/new-user/backup-seed-phrase">
          <BackupSeedPhrase />
        </Route>

        <Route exact path="/new-user/success">
          <ImportOrCreatedSuccess />
        </Route>

        <Route exact path="/new-user/ready">
          <ReadyToUse />
        </Route>

        <Route exact path="/new-user/import/select-address">
          <NewUserSelectAddress />
        </Route>

        <Route exact path="/password">
          <CreatePassword />
        </Route>

        <Route exact path="/no-address">
          <NoAddress />
        </Route>

        <Route exact path="/connect-approval">
          <ConnectApproval />
        </Route>

        <PrivateRoute exact path="/mnemonics/create">
          <CreateMnemonics />
        </PrivateRoute>
        <Route exact path="/biometric-unlock-setup">
          <BiometricUnlockSetup />
        </Route>
        <PrivateRoute exact path="/import">
          <ImportMode />
        </PrivateRoute>
        <PrivateRoute exact path="/import/key">
          <ImportPrivateKey />
        </PrivateRoute>
        <PrivateRoute exact path="/import/json">
          <ImportJson />
        </PrivateRoute>
        <PrivateRoute exact path="/import/mnemonics">
          <InputMnemonics />
        </PrivateRoute>
        <PrivateRoute exact path="/import/select-address">
          <SelectAddress />
        </PrivateRoute>
        <PrivateRoute exact path="/import/hardware">
          <ImportHardware />
        </PrivateRoute>
        <PrivateRoute exact path="/import/hardware/ledger-connect">
          <ConnectLedger />
        </PrivateRoute>
        <PrivateRoute exact path="/import/hardware/trezor-connect">
          <ConnectTrezor />
        </PrivateRoute>
        <PrivateRoute exact path="/import/hardware/onekey">
          <ConnectOneKey />
        </PrivateRoute>
        <PrivateRoute exact path="/import/hardware/imkey-connect">
          <ImKeyConnect />
        </PrivateRoute>
        <PrivateRoute exact path="/import/hardware/keystone">
          <KeystoneConnect />
        </PrivateRoute>
        <PrivateRoute exact path="/import/hardware/qrcode">
          <QRCodeConnect />
        </PrivateRoute>
        <PrivateRoute exact path="/import/watch-address">
          <ImportWatchAddress />
        </PrivateRoute>
        <PrivateRoute exact path="/import/wallet-connect">
          <WalletConnectTemplate />
        </PrivateRoute>
        <PrivateRoute exact path="/popup/import/success">
          <ImportSuccess isPopup />
        </PrivateRoute>
        <PrivateRoute exact path="/import/success">
          <ImportSuccess />
        </PrivateRoute>

        <PrivateRoute exact path="/import/add-from-current-seed-phrase">
          <AddFromCurrentSeedPhrase />
        </PrivateRoute>

        <PrivateRoute exact path="/add-address/new-address">
          <AddNewAddress />
        </PrivateRoute>

        <PrivateRoute exact path="/add-address/import">
          <ImportKeyOrSeed />
        </PrivateRoute>

        <PrivateRoute exact path="/add-address/bulk-import-private-key">
          <BulkImportPrivateKey />
        </PrivateRoute>

        <PrivateRoute exact path="/add-address/create-address-success">
          <CreateAddressSuccess />
        </PrivateRoute>

        <PrivateRoute exact path="/add-address/import-address-success">
          <ImportAddressSuccess />
        </PrivateRoute>

        <PrivateRoute exact path="/add-address/add-more-from-seed-phrase">
          <AddMoreAddressesFromSeedPhrase />
        </PrivateRoute>

        <PrivateRoute exact path="/add-address/hardware-wallets">
          <HardwareWallets />
        </PrivateRoute>

        <PrivateRoute exact path="/add-address/institutional-wallets">
          <InstitutionalWallets />
        </PrivateRoute>

        <PrivateRoute exact path="/history">
          <HistoryPage />
        </PrivateRoute>
        <PrivateRoute exact path="/history/filter-scam">
          <HistoryPage />
        </PrivateRoute>
        <PrivateRoute exact path="/activities">
          <Activities />
        </PrivateRoute>
        <PrivateRoute exact path="/gnosis-queue">
          <GnosisQueue />
        </PrivateRoute>
        <PrivateRoute exact path="/import/gnosis">
          <ImportGnosis />
        </PrivateRoute>
        <PrivateRoute exact path="/import/cobo-argus">
          <ImportCoboArgus />
        </PrivateRoute>
        <PrivateRoute exact path="/import/coinbase">
          <ImportCoinbase />
        </PrivateRoute>
        <PrivateRoute exact path="/add-address">
          <AddAddress />
        </PrivateRoute>
        <PrivateRoute exact path="/approval">
          <Approval />
        </PrivateRoute>
        <PrivateRoute exact path="/revoke-approvals/batch-revoke">
          <ManageBatchRevokeApprovals />
        </PrivateRoute>
        <PrivateRoute exact path="/revoke-approvals">
          <ManageApprovals />
        </PrivateRoute>
        <PrivateRoute exact path="/token-approval">
          <TokenApproval />
        </PrivateRoute>
        <PrivateRoute exact path="/nft-approval">
          <NFTApproval />
        </PrivateRoute>
        <PrivateRoute exact path="/settings/address">
          <ManageAddress />
        </PrivateRoute>
        <PrivateRoute exact path="/settings/address-detail">
          <AddressDetail />
        </PrivateRoute>
        <PrivateRoute exact path="/settings/address-backup/private-key">
          <AddressBackupPrivateKey />
        </PrivateRoute>
        <PrivateRoute exact path="/settings/address-backup/mneonics">
          <AddressBackupMnemonics />
        </PrivateRoute>
        <PrivateRoute exact path="/settings/sites">
          <ConnectedSites />
        </PrivateRoute>
        <PrivateRoute exact path="/settings/chain-list">
          <ChainList />
        </PrivateRoute>
        <PrivateRoute exact path="/settings/switch-lang">
          <SwitchLang />
        </PrivateRoute>
        <PrivateRoute exact path="/settings/advanced">
          <AdvancedSettings />
        </PrivateRoute>
        <PrivateRoute exact path="/request-permission">
          <RequestPermission />
        </PrivateRoute>
        <PrivateRoute exact path="/send-token">
          <SendToken />
        </PrivateRoute>
        <PrivateRoute exact path="/select-to-address">
          <SelectToAddress />
        </PrivateRoute>
        <PrivateRoute exact path="/send-nft">
          <SendNFT />
        </PrivateRoute>
        <PrivateRoute exact path="/whitelist-input">
          <WhitelistInput />
        </PrivateRoute>
        <PrivateRoute exact path="/receive">
          <Receive />
        </PrivateRoute>

        <PrivateRoute exact path="/bridge">
          <Bridge />
        </PrivateRoute>

        <PrivateRoute exact path="/dapp-search">
          <DappSearchPage />
        </PrivateRoute>

        <PrivateRoute exact path="/import/metamask">
          <ImportMyMetaMaskAccount />
        </PrivateRoute>

        <PrivateRoute exact path="/switch-address">
          <AddressManagement />
        </PrivateRoute>

        <PrivateRoute exact path="/dex-swap">
          <Swap />
        </PrivateRoute>
        <PrivateRoute exact path="/custom-rpc">
          <CustomRPC />
        </PrivateRoute>
        <PrivateRoute exact path="/custom-testnet">
          <CustomTestnet />
        </PrivateRoute>
        <PrivateRoute exact path="/metamask-mode-dapps">
          <MetamaskModeDappsGuide />
        </PrivateRoute>
        <PrivateRoute exact path="/metamask-mode-dapps/list">
          <MetamaskModeDappsList />
        </PrivateRoute>
        <PrivateRoute exact path="/nft">
          <NFTView />
        </PrivateRoute>
        <PrivateRoute exact path="/rabby-points">
          <RabbyPoints />
        </PrivateRoute>
        <PrivateRoute path="/ecology/:chainId">
          <Ecology />
        </PrivateRoute>
        <PrivateRoute path="/gas-account">
          <GasAccount />
        </PrivateRoute>
        <PrivateRoute exact path="/perps">
          <Perps />
        </PrivateRoute>
        <PrivateRoute exact path="/perps/single-coin/:coin">
          <PerpsSingleCoin />
        </PrivateRoute>
        <PrivateRoute exact path="/perps/explore">
          <ExploreMore />
        </PrivateRoute>
        <PrivateRoute exact path="/perps/history/:coin">
          <PerpsHistoryPage />
        </PrivateRoute>
        <PrivateRoute exact path="/staking">
          <Staking />
        </PrivateRoute>
        <PrivateRoute exact path="/staking/detail">
          <StakingDetail />
        </PrivateRoute>
      </Switch>

      <CommonPopup />
      <PortalHost />
      <GlobalSignerPortal />
      <GlobalTypedDataSignerPortal />
    </>
  );
};

export default Main;
