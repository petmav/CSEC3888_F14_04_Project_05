import { Message } from '@/utils/message';
import PortMessage from '@/utils/message/portMessage';
import browser from 'webextension-polyfill';

import { EXTENSION_MESSAGES } from '@/constant/message';
import { isManifestV3 } from '@/utils/env';

const createDefer = <T>() => {
  let resolve: ((value: T) => void) | undefined;
  let reject: ((reason?: any) => void) | undefined;

  const promise: Promise<T> = new Promise(function (_resolve, _reject) {
    resolve = _resolve;
    reject = _reject;
  });

  return {
    promise,
    resolve,
    reject,
  };
};

const injectProviderScript = (isDefaultWallet: boolean) => {
  // the script element with src won't execute immediately
  // use inline script element instead!
  const container = document.head || document.documentElement;
  const ele = document.createElement('script');
  // in prevent of webpack optimized code do some magic(e.g. double/sigle quote wrap),
  // separate content assignment to two line
  // use AssetReplacePlugin to replace pageprovider content
  ele.setAttribute('src', browser.runtime.getURL('pageProvider.js'));
  container.insertBefore(ele, container.children[0]);
  container.removeChild(ele);
};

const { BroadcastChannelMessage } = Message;

let pm: PortMessage | null;
let defer = createDefer<PortMessage>();

const bcm = new BroadcastChannelMessage({
  name: 'rabby-content-script',
  target: 'rabby-page-provider',
}).listen((data) => {
  browser.runtime.sendMessage({ type: 'ping' });
  if (pm) {
    return pm?.request(data);
  }
  return defer.promise.then((pm) => pm?.request(data));
});

// background notification

document.addEventListener('beforeunload', () => {
  bcm.dispose();
  pm?.dispose();
});

const handlePmMessage = (data) => bcm.send('message', data);

const onDisconnectDestroyStreams = (err) => {
  pm?.port?.onDisconnect.removeListener(onDisconnectDestroyStreams);
  pm?.off('message', handlePmMessage);

  pm?.dispose();
  pm = null;
  defer = createDefer<PortMessage>();
};

const setupExtensionStreams = () => {
  pm = new PortMessage().connect();
  pm?.on('message', handlePmMessage);
  defer.resolve?.(pm);
  pm?.port?.onDisconnect.addListener(onDisconnectDestroyStreams);
  bcm.send('message', { event: 'contentScriptConnected' });
};

setupExtensionStreams();

const onMessageSetUpExtensionStreams = (msg) => {
  if (msg.name === EXTENSION_MESSAGES.READY) {
    if (!pm) {
      setupExtensionStreams();
    }
    return Promise.resolve(`Rabby: handled ${EXTENSION_MESSAGES.READY}`);
  }
  return undefined;
};
browser.runtime.onMessage.addListener(onMessageSetUpExtensionStreams);

if (!isManifestV3) {
  injectProviderScript(false);
}

const getHardcodedBlockedHosts = (): string[] => {
  const hosts = ['app.hyperliquid.xyz'];
  try {
    hosts.push(new URL(browser.runtime.getURL('')).hostname);
  } catch {
    // best-effort: skip if the extension origin can't be resolved
  }
  return hosts;
};

(async () => {
  try {
    if (window.top !== window) return;
    // Disabled is the default, so gate on `enabled` first and skip the second
    // round-trip entirely on the (hot) every-page-load path when it's off.
    const enabled = (await browser.runtime.sendMessage({
      type: 'controller',
      method: 'getPerpsWidgetEnabled',
      params: [],
    })) as boolean;
    if (!enabled) return;
    const blockedHosts = (await browser.runtime.sendMessage({
      type: 'controller',
      method: 'getPerpsWidgetBlockedHosts',
      params: [],
    })) as string[];
    // webpackMode: 'eager' inlines the widget into content-script.js. Without it,
    // strict-CSP hosts (Google, GitHub) reject the chunk fetched from chrome-extension://.
    const { bootPerpsWidget } = await import(
      /* webpackMode: "eager" */ './perps-widget'
    );
    await bootPerpsWidget({
      enabled: true,
      blockedHosts: [
        ...getHardcodedBlockedHosts(),
        ...(Array.isArray(blockedHosts) ? blockedHosts : []),
      ],
    });
  } catch (err) {
    console.warn('[perps-widget] bootstrap failed', err);
  }
})();
