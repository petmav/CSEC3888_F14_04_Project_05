import {
  ensureChainHashValid,
  ensureChainListValid,
  getChainList,
  getMainnetChainList,
} from '@/utils/chain';
import { CHAINS, CHAINS_ENUM, Chain } from '@debank/common';
import { Level } from '@rabby-wallet/rabby-security-engine/dist/rules';
import { DEX_ENUM, DEX_SUPPORT_CHAINS } from '@rabby-wallet/rabby-swap';
import IconClosed, {
  ReactComponent as RcIconClosed,
} from 'ui/assets/sign/security-engine/closed.svg';
import IconDanger, {
  ReactComponent as RcIconDanger,
} from 'ui/assets/sign/security-engine/danger.svg';
import IconError, {
  ReactComponent as RcIconError,
} from 'ui/assets/sign/security-engine/error.svg';
import IconForbidden, {
  ReactComponent as RcIconForbidden,
} from 'ui/assets/sign/security-engine/forbidden.svg';
import IconProceed, {
  ReactComponent as RcIconProceed,
} from 'ui/assets/sign/security-engine/processed.svg';
import IconSafe, {
  ReactComponent as RcIconSafe,
} from 'ui/assets/sign/security-engine/safe.svg';
import IconWarning, {
  ReactComponent as RcIconWarning,
} from 'ui/assets/sign/security-engine/warning.svg';
import LogoCoboArgus, {
  ReactComponent as RcLogoCoboArgus,
} from 'ui/assets/walletlogo/CoboArgus.svg';
import IconMnemonicWhiteRaw, {
  ReactComponent as RcIconMnemonicWhite,
} from 'ui/assets/walletlogo/IconMnemonic-white.svg';
import IconMnemonicDesktopWhite, {
  ReactComponent as RcIconMnemonicDesktopWhite,
} from 'ui/assets/walletlogo/IconMnemonic-desktop-white.svg';
import IconWatchWhite, {
  ReactComponent as RcIconWatchWhite,
} from 'ui/assets/walletlogo/IconWatch-white.svg';
import IconWatchInk, {
  ReactComponent as RcIconWatchInk,
} from 'ui/assets/walletlogo/icon-watch-ink.svg';

import LogoAirGap, {
  ReactComponent as RcLogoAirGap,
} from 'ui/assets/walletlogo/airgap.svg';
import {
  default as IconAmber,
  default as LogoAmber,
  ReactComponent as RcIconAmber,
  ReactComponent as RcLogoAmber,
} from 'ui/assets/walletlogo/amber.svg';
import {
  default as IconBitBox02,
  default as IconBitBox02WithBorder,
  ReactComponent as RcIconBitBox02,
  ReactComponent as RcIconBitBox02WithBorder,
} from 'ui/assets/walletlogo/bitbox.svg';
import LogoBitkeep, {
  ReactComponent as RcLogoBitkeep,
} from 'ui/assets/walletlogo/bitkeep.svg';
import {
  default as IconCobo,
  default as LogoCobo,
  ReactComponent as RcIconCobo,
  ReactComponent as RcLogoCobo,
} from 'ui/assets/walletlogo/cobo.svg';
import IconCoinbase, {
  ReactComponent as RCIconCoinbase,
} from 'ui/assets/walletlogo/coinbase.svg';
import LogoCoolWallet, {
  ReactComponent as RcLogoCoolWallet,
} from 'ui/assets/walletlogo/coolwallet.svg';
import {
  default as LogoDefiant,
  default as LogoDefiantWhite,
  ReactComponent as RcLogoDefiant,
  ReactComponent as RcLogoDefiantWhite,
} from 'ui/assets/walletlogo/defiant.svg';
import {
  default as IconFireblocks,
  default as IconFireblocksWithBorder,
  ReactComponent as RcIconFireblocks,
  ReactComponent as RcIconFireblocksWithBorder,
} from 'ui/assets/walletlogo/fireblocks.svg';
import IconGridPlus, {
  ReactComponent as RcIconGridPlus,
} from 'ui/assets/walletlogo/gridplus.svg';
import LogoImtokenOffline, {
  ReactComponent as RcLogoImtokenOffline,
} from 'ui/assets/walletlogo/imTokenOffline.svg';
import IconImKey, {
  ReactComponent as RCIconImKey,
} from 'ui/assets/walletlogo/imkey.svg';
import {
  default as IconImtoken,
  default as LogoImtoken,
  ReactComponent as RcIconImtoken,
  ReactComponent as RcLogoImtoken,
} from 'ui/assets/walletlogo/imtoken.svg';
import {
  default as IconJade,
  default as LogoJade,
  ReactComponent as RcIconJade,
  ReactComponent as RcLogoJade,
} from 'ui/assets/walletlogo/jade.svg';
import LogoKeystone, {
  ReactComponent as RcLogoKeystone,
} from 'ui/assets/walletlogo/keystone.svg';
import {
  default as LogoLedgerDark,
  default as LogoLedgerWhite,
  ReactComponent as RcLogoLedgerDark,
  ReactComponent as RcLogoLedgerWhite,
} from 'ui/assets/walletlogo/ledger.svg';
import LogoLedgerDisable, {
  ReactComponent as RcLogoLedgerDisable,
} from 'ui/assets/walletlogo/ledgerDisable.svg';
import {
  default as IconMath,
  default as LogoMath,
  ReactComponent as RcIconMath,
  ReactComponent as RcLogoMath,
} from 'ui/assets/walletlogo/math.svg';
import IconMetaMask, {
  ReactComponent as RcIconMetaMask,
} from 'ui/assets/walletlogo/metamask.svg';
import IconMnemonicInkRaw, {
  ReactComponent as RcIconMnemonicInk,
} from 'ui/assets/walletlogo/mnemonic-ink.svg';
import IconMnemonicDesktopInk, {
  ReactComponent as RcIconMnemonicDesktopInk,
} from 'ui/assets/walletlogo/mnemonic-desktop-ink.svg';
import LogoMPCVault, {
  ReactComponent as RcLogoMPCVault,
} from 'ui/assets/walletlogo/mpcvault.svg';
import IconNgrave, {
  ReactComponent as RCIconNgrave,
} from 'ui/assets/walletlogo/ngrave.svg';
import {
  default as IconOneKey18,
  default as IconOnekey,
  default as LogoOnekey,
  ReactComponent as RcIconOneKey18,
  ReactComponent as RcIconOnekey,
  ReactComponent as RcLogoOnekey,
} from 'ui/assets/walletlogo/onekey.svg';
import IconPrivateKeyWhiteRaw, {
  ReactComponent as RcIconPrivateKeyWhite,
} from 'ui/assets/walletlogo/private-key-white.svg';
import IconPrivateKeyDesktopWhite, {
  ReactComponent as RcIconPrivateKeyDesktopWhite,
} from 'ui/assets/walletlogo/private-key-desktop-white.svg';
import IconPrivateKeyInkRaw, {
  ReactComponent as RcIconPrivateKeyInk,
} from 'ui/assets/walletlogo/privatekey-ink.svg';
import IconPrivateKeyDesktopInk, {
  ReactComponent as RcIconPrivateKeyDesktopInk,
} from 'ui/assets/walletlogo/privatekey-desktop-ink.svg';
import LogoPrivateKey, {
  ReactComponent as RcLogoPrivateKey,
} from 'ui/assets/walletlogo/privatekeylogo.svg';
import LogoRainbow, {
  ReactComponent as RcLogoRainbow,
} from 'ui/assets/walletlogo/rainbow.svg';
import IconGnosis, {
  ReactComponent as RcIconGnosis,
} from 'ui/assets/walletlogo/safe.svg';
import {
  default as IconTokenpocket,
  default as LogoTp,
  ReactComponent as RcIconTokenpocket,
  ReactComponent as RcLogoTp,
} from 'ui/assets/walletlogo/tp.svg';
import {
  default as IconTrezor,
  default as IconTrezor24,
  default as IconTrezor24Border,
  default as LogoTrezor,
  ReactComponent as RcIconTrezor,
  ReactComponent as RcIconTrezor24,
  ReactComponent as RcIconTrezor24Border,
  ReactComponent as RcLogoTrezor,
} from 'ui/assets/walletlogo/trezor.svg';
import {
  default as IconTrust,
  default as LogoTrust,
  ReactComponent as RcIconTrust,
  ReactComponent as RcLogoTrust,
} from 'ui/assets/walletlogo/trust.svg';
import IconUtila, {
  ReactComponent as RCIconUtila,
} from 'ui/assets/walletlogo/utila.svg';
import {
  default as LogoWalletConnect,
  default as LogoWalletConnectWhite,
  ReactComponent as RcLogoWalletConnect,
  ReactComponent as RcLogoWalletConnectWhite,
} from 'ui/assets/walletlogo/walletconnect.svg';
import IconWatchPurple, {
  ReactComponent as RcIconWatchPurple,
} from 'ui/assets/walletlogo/watch-purple.svg';

import IconWhiteListWhite from 'ui/assets/walletlogo/whitelist-white.svg';

import IconWhiteListDark from 'ui/assets/walletlogo/whitelist-dark.svg';

import LogoZerion, {
  ReactComponent as RcLogoZerion,
} from 'ui/assets/walletlogo/zerion.svg';
import browser from 'webextension-polyfill';

import Logo0X from 'ui/assets/swap/0xswap.png';
import Logo1inch from 'ui/assets/swap/1inch.svg';
import LogoOdos from 'ui/assets/swap/odos.png';
import LogoParaswap from 'ui/assets/swap/paraswap.png';
import LogoMagpie from 'ui/assets/swap/magpie.png';
import LogoSushi from 'ui/assets/swap/sushi.png';
import LogoUniswap from 'ui/assets/swap/uniswap.png';

import { REDBELLY_MAINNET } from './redbelly-chains';
import { WALLET_NAME } from './redbelly';
import LogoBinance from 'ui/assets/swap/binance.png';
import LogoCoinbase from 'ui/assets/swap/coinbase.png';
import LogoKyberSwap from 'ui/assets/swap/kyberswap.png';
import LogoOkx from 'ui/assets/swap/okx.png';
import LogoOpenOcean from 'ui/assets/swap/openocean.png';
import LogoTokenDefault from 'ui/assets/token-default.svg';

export { default as LANGS } from '../../_raw/locales/index.json';

export { CHAINS, CHAINS_ENUM };

const isDesktop =
  typeof window !== 'undefined' && window.location.pathname === '/desktop.html';
const IconPrivateKeyInk = isDesktop
  ? IconPrivateKeyDesktopInk
  : IconPrivateKeyInkRaw;

const IconPrivateKeyWhite = isDesktop
  ? IconPrivateKeyDesktopWhite
  : IconPrivateKeyWhiteRaw;

const IconMnemonicInk = isDesktop ? IconMnemonicDesktopInk : IconMnemonicInkRaw;
const IconMnemonicWhite = isDesktop
  ? IconMnemonicDesktopWhite
  : IconMnemonicWhiteRaw;

interface PortfolioChain extends Chain {
  isSupportHistory: boolean;
}

export const CHAIN_ID_LIST = new Map<string, PortfolioChain>(
  getChainList('mainnet').map((chain) => {
    return [chain.serverId, { ...chain, isSupportHistory: false }];
  })
);

export const syncChainIdList = () => {
  const chainList = getChainList('mainnet');
  for (const chain of chainList) {
    if (!CHAIN_ID_LIST.has(chain.serverId)) {
      CHAIN_ID_LIST.set(chain.serverId, {
        ...chain,
        isSupportHistory: false,
      });
    }
  }
};

export const KEYRING_TYPE = {
  HdKeyring: 'HD Key Tree',
  SimpleKeyring: 'Simple Key Pair',
  HardwareKeyring: 'hardware',
  WatchAddressKeyring: 'Watch Address',
  WalletConnectKeyring: 'WalletConnect',
  GnosisKeyring: 'Gnosis',
  CoboArgusKeyring: 'CoboArgus',
  CoinbaseKeyring: 'Coinbase',
  /**
   * just for type, not a real keyring type
   */
  Whitelist: 'Whitelist',
} as const;

const createHardwareObject = () => {
  const hardware = {
    BITBOX02: 'BitBox02 Hardware',
    TREZOR: 'Trezor Hardware',
    LEDGER: 'Ledger Hardware',
    ONEKEY: 'Onekey Hardware',
    GRIDPLUS: 'GridPlus Hardware',
    KEYSTONE: 'QR Hardware Wallet Device',
    IMKEY: 'imKey Hardware',
    NGRAVEZERO: 'QR Hardware Wallet Device',
  };

  return hardware;
};

export const KEYRING_CLASS = {
  PRIVATE_KEY: 'Simple Key Pair',
  MNEMONIC: 'HD Key Tree',
  HARDWARE: createHardwareObject(),
  WATCH: 'Watch Address',
  WALLETCONNECT: 'WalletConnect',
  GNOSIS: 'Gnosis',
  CoboArgus: 'CoboArgus',
  Coinbase: 'Coinbase',
  /**
   * just for type, not a real keyring type
   */
  Whitelist: 'Whitelist',
} as const;

export const CORE_KEYRING_TYPES = [
  KEYRING_CLASS.MNEMONIC,
  KEYRING_CLASS.PRIVATE_KEY,
  ...Object.values(KEYRING_CLASS.HARDWARE),
];

export const KEYRING_WITH_INDEX = [
  KEYRING_CLASS.HARDWARE.LEDGER,
  KEYRING_CLASS.HARDWARE.GRIDPLUS,
];

export const SUPPORT_1559_KEYRING_TYPE = [
  KEYRING_CLASS.HARDWARE.LEDGER,
  KEYRING_CLASS.HARDWARE.GRIDPLUS,
  KEYRING_CLASS.PRIVATE_KEY,
  KEYRING_CLASS.MNEMONIC,
  KEYRING_CLASS.HARDWARE.KEYSTONE,
  KEYRING_CLASS.HARDWARE.NGRAVEZERO,
  KEYRING_CLASS.HARDWARE.TREZOR,
  KEYRING_CLASS.HARDWARE.ONEKEY,
  KEYRING_CLASS.HARDWARE.BITBOX02,
];

export const KEYRING_TYPE_TEXT = {
  [KEYRING_TYPE.HdKeyring]: 'Created by Seed Phrase',
  [KEYRING_TYPE.SimpleKeyring]: 'Imported by Private Key',
  [KEYRING_TYPE.WatchAddressKeyring]: 'Watch-only',
  [KEYRING_CLASS.HARDWARE.BITBOX02]: 'Imported by BitBox02',
  [KEYRING_CLASS.HARDWARE.LEDGER]: 'Imported by Ledger',
  [KEYRING_CLASS.HARDWARE.TREZOR]: 'Imported by Trezor',
  [KEYRING_CLASS.HARDWARE.ONEKEY]: 'Imported by Onekey',
  [KEYRING_CLASS.HARDWARE.GRIDPLUS]: 'Imported by GridPlus',
  [KEYRING_CLASS.GNOSIS]: 'Imported by Safe',
  [KEYRING_CLASS.HARDWARE.KEYSTONE]: 'Imported by QRCode Base',
  [KEYRING_CLASS.HARDWARE.NGRAVEZERO]: 'Imported by QRCode Base',
  [KEYRING_CLASS.HARDWARE.IMKEY]: 'Imported by imKey',
};

export const HARDWARE_KEYRING_TYPES = {
  BitBox02: {
    type: 'BitBox02 Hardware',
    brandName: 'BitBox02',
  },
  Ledger: {
    type: 'Ledger Hardware',
    brandName: 'Ledger',
  },
  Trezor: {
    type: 'Trezor Hardware',
    brandName: 'Trezor',
  },
  Onekey: {
    type: 'Onekey Hardware',
    brandName: 'Onekey',
  },
  GridPlus: {
    type: 'GridPlus Hardware',
    brandName: 'GridPlus',
  },
  Keystone: {
    type: 'QR Hardware Wallet Device',
    brandName: 'Keystone',
  },
  NGRAVEZERO: {
    type: 'QR Hardware Wallet Device',
    brandName: 'NGRAVE ZERO',
  },
  ImKey: {
    type: 'imKey Hardware',
    brandName: 'imKey',
  },
} as const;

export enum TX_TYPE_ENUM {
  SEND = 1,
  APPROVE = 2,
  CANCEL_APPROVE = 3,
  CANCEL_TX = 4,
  SIGN_TX = 5,
}

export const IS_CHROME = /Chrome\//i.test(global.navigator?.userAgent);

export const IS_FIREFOX = /Firefox\//i.test(global.navigator?.userAgent);

export let IS_VIVALDI = false;
browser.tabs.onCreated.addListener((tab) => {
  if (tab && 'vivExtData' in tab) {
    IS_VIVALDI = true;
  }
});

export const IS_LINUX = /linux/i.test(global.navigator?.userAgent);

let chromeVersion: number | null = null;

if (IS_CHROME) {
  const matches = global.navigator?.userAgent.match(/Chrome\/(\d+[^.\s])/);
  if (matches && matches.length >= 2) {
    chromeVersion = Number(matches[1]);
  }
}

export const IS_AFTER_CHROME91 = IS_CHROME
  ? chromeVersion && chromeVersion >= 91
  : false;

export const GAS_LEVEL_TEXT = {
  $unknown: 'Unknown',
  slow: 'Standard',
  normal: 'Fast',
  fast: 'Instant',
  custom: 'Custom',
} as const;

export const IS_WINDOWS = /windows/i.test(global.navigator?.userAgent);

export const CHECK_METAMASK_INSTALLED_URL = {
  Chrome: 'chrome-extension://nkbihfbeogaeaoehlefnkodbefgpgknn/phishing.html',
  Firefox: '',
  Brave: '',
  Edge: '',
};

export const SAFE_RPC_METHODS = [
  'eth_blockNumber',
  'eth_call',
  'eth_chainId',
  'eth_coinbase',
  'eth_decrypt',
  'eth_estimateGas',
  'eth_gasPrice',
  'eth_getBalance',
  'eth_getBlockByHash',
  'eth_getBlockByNumber',
  'eth_getBlockTransactionCountByHash',
  'eth_getBlockTransactionCountByNumber',
  'eth_getCode',
  'eth_getEncryptionPublicKey',
  'eth_getFilterChanges',
  'eth_getFilterLogs',
  'eth_getLogs',
  'eth_getProof',
  'eth_getStorageAt',
  'eth_getTransactionByBlockHashAndIndex',
  'eth_getTransactionByBlockNumberAndIndex',
  'eth_getTransactionByHash',
  'eth_getTransactionCount',
  'eth_getTransactionReceipt',
  'eth_getUncleByBlockHashAndIndex',
  'eth_getUncleByBlockNumberAndIndex',
  'eth_getUncleCountByBlockHash',
  'eth_getUncleCountByBlockNumber',
  'eth_getWork',
  'eth_hashrate',
  'eth_mining',
  'eth_newBlockFilter',
  'eth_newFilter',
  'eth_newPendingTransactionFilter',
  'eth_protocolVersion',
  'eth_sendRawTransaction',
  'eth_sendTransaction',
  'eth_submitHashrate',
  'eth_submitWork',
  'eth_syncing',
  'eth_uninstallFilter',
  'wallet_requestPermissions',
  'wallet_revokePermissions',
  'wallet_getPermissions',
  'net_version',
];

export const MINIMUM_GAS_LIMIT = 21000;

export enum WATCH_ADDRESS_CONNECT_TYPE {
  WalletConnect = 'WalletConnect',
}

export enum BRAND_WALLET_CONNECT_TYPE {
  WalletConnect = 'WalletConnect',
  BitBox02Connect = 'BitBox02Connect',
  LedgerConnect = 'LedgerConnect',
  OneKeyConnect = 'OneKeyConnect',
  TrezorConnect = 'TrezorConnect',
  GnosisConnect = 'GnosisConnect',
  GridPlusConnect = 'GridPlusConnect',
  QRCodeBase = 'QR Hardware Wallet Device',
  CoboArgusConnect = 'CoboArgusConnect',
  CoinbaseConnect = 'CoinbaseConnect',
  ImKeyConnect = 'ImKeyConnect',
}

export const WALLETCONNECT_STATUS_MAP = {
  PENDING: 1,
  CONNECTED: 2,
  WAITING: 3,
  SUBMITTED: 4,
  REJECTED: 5,
  FAILED: 6,
  SUBMITTING: 7,
};

export const INTERNAL_REQUEST_ORIGIN = location.origin;

export const INTERNAL_REQUEST_SESSION = {
  name: WALLET_NAME,
  origin: INTERNAL_REQUEST_ORIGIN,
  // The wallet's own avatar on approval screens. Shares the Redbelly chain
  // logo so there is one place to set the brand mark.
  icon: REDBELLY_MAINNET.logo,
};

export const INITIAL_OPENAPI_URL = 'https://api.rabby.io';

export const EVENTS = {
  BRIDGE_HISTORY_UPDATED: 'BRIDGE_HISTORY_UPDATED',
  broadcastToUI: 'broadcastToUI',
  broadcastToBackground: 'broadcastToBackground',
  TX_COMPLETED: 'TX_COMPLETED',
  SIGN_FINISHED: 'SIGN_FINISHED',
  TX_SUBMITTING: 'TX_SUBMITTING',
  WALLETCONNECT: {
    STATUS_CHANGED: 'WALLETCONNECT_STATUS_CHANGED',
    SESSION_STATUS_CHANGED: 'SESSION_STATUS_CHANGED',
    SESSION_ACCOUNT_CHANGED: 'SESSION_ACCOUNT_CHANGED',
    SESSION_NETWORK_DELAY: 'SESSION_NETWORK_DELAY',
    INIT: 'WALLETCONNECT_INIT',
    INITED: 'WALLETCONNECT_INITED',
    TRANSPORT_ERROR: 'TRANSPORT_ERROR',
    SCAN_ACCOUNT: 'SCAN_ACCOUNT',
  },
  GNOSIS: {
    TX_BUILT: 'TransactionBuilt',
    TX_CONFIRMED: 'TransactionConfirmed',
  },
  QRHARDWARE: {
    ACQUIRE_MEMSTORE_SUCCEED: 'ACQUIRE_MEMSTORE_SUCCEED',
  },
  LEDGER: {
    REJECTED: 'LEDGER_REJECTED',
    REJECT_APPROVAL: 'LEDGER_REJECT_APPROVAL',
  },
  COMMON_HARDWARE: {
    REJECTED: 'COMMON_HARDWARE_REJECTED',
  },
  ONEKEY: {
    REQUEST_PERMISSION_WEBUSB: 'ONEKEY_REQUEST_PERMISSION_WEBUI',
  },
  LOCK_WALLET: 'LOCK_WALLET',
  UNLOCK_WALLET: 'UNLOCK_WALLET',
  // Boot/lock state changed out of band. Unlike LOCK_WALLET this carries no
  // navigation intent, so the page that triggered the change keeps its route.
  WALLET_STATUS_CHANGED: 'WALLET_STATUS_CHANGED',
  RELOAD_TX: 'RELOAD_TX',
  SIGN_BEGIN: 'SIGN_BEGIN',
  SIGN_WAITING_AMOUNTED: 'SIGN_WAITING_AMOUNTED',
  DIRECT_SIGN: 'DIRECT_SIGN',
  // FORCE_EXPIRE_ADDRESS_BALANCE: 'FORCE_EXPIRE_ADDRESS_BALANCE',
  GAS_ACCOUNT: {
    LOG_IN: 'LOG_IN',
    LOG_OUT: 'LOG_OUT',
    CLOSE_WINDOW: 'CLOSE_WINDOW',
    DISCOVERY_UPDATED: 'DISCOVERY_UPDATED',
  },
  PERPS: {
    LOG_OUT: 'PERPS_LOG_OUT',
    HANDLE_CLICK_PRICE: 'PERPS_HANDLE_CLICK_PRICE',
    SWITCH_LIMIT_FILL_PRICE: 'SWITCH_LIMIT_FILL_PRICE',
    USER_INFO_HISTORY_TAB_CHANGED: 'PERPS_USER_INFO_HISTORY_TAB_CHANGED',
    WIDGET_ACCOUNT_CHANGED: 'PERPS_WIDGET_ACCOUNT_CHANGED',
    WIDGET_ENABLED_CHANGED: 'PERPS_WIDGET_ENABLED_CHANGED',
    WIDGET_BLOCKED_HOSTS_CHANGED: 'PERPS_WIDGET_BLOCKED_HOSTS_CHANGED',
  },
  INNER_HISTORY_ITEM_PENDING: 'INNER_HISTORY_ITEM_PENDING',
  INNER_HISTORY_ITEM_COMPLETE: 'INNER_HISTORY_ITEM_COMPLETE',
  PERSIST_KEYRING: 'PERSIST_KEYRING',

  RELOAD_ACCOUNT_LIST: 'RELOAD_ACCOUNT_LIST',

  DESKTOP: {
    FOCUSED: 'DESKTOP_FOCUSED',
    SWITCH_PERPS_ACCOUNT: 'DESKTOP_SWITCH_PERPS_ACCOUNT',
  },

  RELOAD_APPROVAL: 'RELOAD_APPROVAL',
};

export const EVENTS_IN_BG = {
  ON_TX_COMPLETED: 'ON_TX_COMPLETED',
};

export enum WALLET_BRAND_TYPES {
  AMBER = 'AMBER',
  BITBOX02 = 'BITBOX02',
  COBO = 'COBO',
  FIREBLOCKS = 'FIREBLOCKS',
  IMTOKEN = 'IMTOKEN',
  JADE = 'JADE',
  LEDGER = 'LEDGER',
  MATHWALLET = 'MATHWALLET',
  ONEKEY = 'ONEKEY',
  TP = 'TP',
  TREZOR = 'TREZOR',
  TRUSTWALLET = 'TRUSTWALLET',
  GNOSIS = 'Gnosis',
  GRIDPLUS = 'GRIDPLUS',
  METAMASK = 'MetaMask',
  KEYSTONE = 'Keystone',
  COOLWALLET = 'CoolWallet',
  DEFIANT = 'Defiant',
  WALLETCONNECT = 'WALLETCONNECT',
  AIRGAP = 'AirGap',
  IMTOKENOFFLINE = 'imTokenOffline',
  Rainbow = 'Rainbow',
  Bitkeep = 'Bitget',
  // Uniswap = 'Uniswap',
  Zerion = 'Zerion',
  CoboArgus = 'CoboArgus',
  MPCVault = 'MPCVault',
  Coinbase = 'Coinbase',
  IMKEY = 'IMKEY',
  NGRAVEZERO = 'NGRAVE ZERO',
  Utila = 'Utila',
}

export enum WALLET_BRAND_CATEGORY {
  MOBILE = 'mobile',
  HARDWARE = 'hardware',
  INSTITUTIONAL = 'institutional',
}

export type ThemeIconType = string | React.FC<React.SVGProps<SVGSVGElement>>;

export type IWalletBrandContent = {
  id: number;
  name: string;
  brand: WALLET_BRAND_TYPES;
  icon: string;
  lightIcon: string;
  // Icon showed out of collapse
  leftIcon?: string;
  image: string;
  rcSvg: Exclude<ThemeIconType, string>;
  /**
   * @description some brand's logo has no dark mode svg because it's colorful,
   * for those brand, we use lightIcon as dark mode svg. When maybeSvg provided
   * for those brand, we set maybeSvg as image string and `ThemeIcon` would rendered
   * as <img />.
   */
  maybeSvg?: ThemeIconType;
  connectType: BRAND_WALLET_CONNECT_TYPE;
  category: WALLET_BRAND_CATEGORY;
  hidden?: boolean;
  preventClick?: boolean;
  tipI18nKey?: string;
};

export const WALLET_BRAND_CONTENT: {
  [K in string]: IWalletBrandContent;
} = {
  [WALLET_BRAND_TYPES.AMBER]: {
    id: 0,
    name: 'Amber',
    brand: WALLET_BRAND_TYPES.AMBER,
    icon: IconAmber,
    lightIcon: IconAmber,
    image: LogoAmber,
    rcSvg: RcLogoAmber,
    maybeSvg: LogoAmber,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.INSTITUTIONAL,
  },
  [WALLET_BRAND_TYPES.BITBOX02]: {
    id: 10,
    name: 'BitBox02',
    brand: WALLET_BRAND_TYPES.BITBOX02,
    icon: IconBitBox02,
    lightIcon: IconBitBox02,
    image: IconBitBox02WithBorder,
    rcSvg: RcIconBitBox02WithBorder,
    maybeSvg: IconBitBox02WithBorder,
    connectType: BRAND_WALLET_CONNECT_TYPE.BitBox02Connect,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
  },
  [WALLET_BRAND_TYPES.COBO]: {
    id: 1,
    name: 'Cobo Wallet',
    brand: WALLET_BRAND_TYPES.COBO,
    icon: IconCobo,
    lightIcon: IconCobo,
    image: LogoCobo,
    rcSvg: RcLogoCobo,
    maybeSvg: LogoCobo,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.INSTITUTIONAL,
    hidden: true,
  },
  [WALLET_BRAND_TYPES.COOLWALLET]: {
    id: 16,
    name: 'CoolWallet',
    brand: WALLET_BRAND_TYPES.COOLWALLET,
    icon: LogoCoolWallet,
    lightIcon: LogoCoolWallet,
    image: LogoCoolWallet,
    rcSvg: RcLogoCoolWallet,
    maybeSvg: LogoCoolWallet,
    connectType: BRAND_WALLET_CONNECT_TYPE.QRCodeBase,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
  },
  [WALLET_BRAND_TYPES.DEFIANT]: {
    id: 17,
    name: 'Defiant',
    brand: WALLET_BRAND_TYPES.DEFIANT,
    icon: LogoDefiant,
    lightIcon: LogoDefiant,
    image: LogoDefiantWhite,
    rcSvg: RcLogoDefiantWhite,
    maybeSvg: LogoDefiantWhite,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
    hidden: true,
  },
  [WALLET_BRAND_TYPES.WALLETCONNECT]: {
    id: 20,
    name: 'Wallet Connect',
    brand: WALLET_BRAND_TYPES.WALLETCONNECT,
    icon: LogoWalletConnect,
    lightIcon: LogoWalletConnect,
    image: LogoWalletConnectWhite,
    rcSvg: RcLogoWalletConnectWhite,
    maybeSvg: LogoWalletConnectWhite,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
  },
  [WALLET_BRAND_TYPES.FIREBLOCKS]: {
    id: 11,
    name: 'Fireblocks',
    brand: WALLET_BRAND_TYPES.FIREBLOCKS,
    icon: IconFireblocks,
    lightIcon: IconFireblocks,
    image: IconFireblocksWithBorder,
    rcSvg: RcIconFireblocksWithBorder,
    maybeSvg: IconFireblocksWithBorder,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.INSTITUTIONAL,
  },
  [WALLET_BRAND_TYPES.GNOSIS]: {
    id: 13,
    name: 'Safe',
    brand: WALLET_BRAND_TYPES.GNOSIS,
    icon: IconGnosis,
    lightIcon: IconGnosis,
    image: IconGnosis,
    rcSvg: RcIconGnosis,
    maybeSvg: IconGnosis,
    connectType: BRAND_WALLET_CONNECT_TYPE.GnosisConnect,
    category: WALLET_BRAND_CATEGORY.INSTITUTIONAL,
  },
  [WALLET_BRAND_TYPES.GRIDPLUS]: {
    id: 12,
    name: 'GridPlus',
    brand: WALLET_BRAND_TYPES.GRIDPLUS,
    icon: IconGridPlus,
    lightIcon: IconGridPlus,
    image: IconGridPlus,
    rcSvg: RcIconGridPlus,
    maybeSvg: IconGridPlus,
    connectType: BRAND_WALLET_CONNECT_TYPE.GridPlusConnect,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
  },
  [WALLET_BRAND_TYPES.IMTOKEN]: {
    id: 2,
    name: 'imToken',
    brand: WALLET_BRAND_TYPES.IMTOKEN,
    icon: IconImtoken,
    lightIcon: IconImtoken,
    image: LogoImtoken,
    rcSvg: RcLogoImtoken,
    maybeSvg: LogoImtoken,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
  },
  [WALLET_BRAND_TYPES.JADE]: {
    id: 3,
    name: 'Jade Wallet',
    brand: WALLET_BRAND_TYPES.JADE,
    icon: IconJade,
    lightIcon: IconJade,
    image: LogoJade,
    rcSvg: RcLogoJade,
    maybeSvg: LogoJade,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.INSTITUTIONAL,
  },
  [WALLET_BRAND_TYPES.KEYSTONE]: {
    id: 15,
    name: 'Keystone',
    brand: WALLET_BRAND_TYPES.KEYSTONE,
    icon: LogoKeystone,
    lightIcon: LogoKeystone,
    image: LogoKeystone,
    rcSvg: RcLogoKeystone,
    maybeSvg: LogoKeystone,
    connectType: BRAND_WALLET_CONNECT_TYPE.QRCodeBase,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
  },
  [WALLET_BRAND_TYPES.AIRGAP]: {
    id: 18,
    name: 'AirGap Vault',
    brand: WALLET_BRAND_TYPES.AIRGAP,
    icon: LogoAirGap,
    lightIcon: LogoAirGap,
    image: LogoAirGap,
    rcSvg: RcLogoAirGap,
    maybeSvg: LogoAirGap,
    connectType: BRAND_WALLET_CONNECT_TYPE.QRCodeBase,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
  },
  [WALLET_BRAND_TYPES.LEDGER]: {
    id: 4,
    name: 'Ledger',
    brand: WALLET_BRAND_TYPES.LEDGER,
    icon: LogoLedgerWhite,
    lightIcon: LogoLedgerWhite,
    leftIcon: LogoLedgerDark,
    image: IS_FIREFOX ? LogoLedgerDisable : LogoLedgerDark,
    rcSvg: IS_FIREFOX ? RcLogoLedgerDisable : RcLogoLedgerDark,
    maybeSvg: LogoLedgerDark,
    connectType: BRAND_WALLET_CONNECT_TYPE.LedgerConnect,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
    preventClick: IS_FIREFOX,
    tipI18nKey: IS_FIREFOX ? 'page.newAddress.firefoxLedgerDisableTips' : '',
  },
  [WALLET_BRAND_TYPES.MATHWALLET]: {
    id: 5,
    name: 'Math Wallet',
    brand: WALLET_BRAND_TYPES.MATHWALLET,
    icon: IconMath,
    lightIcon: IconMath,
    image: LogoMath,
    rcSvg: RcLogoMath,
    maybeSvg: LogoMath,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
  },
  [WALLET_BRAND_TYPES.METAMASK]: {
    id: 14,
    name: 'MetaMask Mobile',
    brand: WALLET_BRAND_TYPES.METAMASK,
    icon: IconMetaMask,
    lightIcon: IconMetaMask,
    image: IconMetaMask,
    rcSvg: RcIconMetaMask,
    maybeSvg: RcIconMetaMask,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
  },
  [WALLET_BRAND_TYPES.ONEKEY]: {
    id: 6,
    name: 'OneKey',
    brand: WALLET_BRAND_TYPES.ONEKEY,
    icon: IconOnekey,
    lightIcon: IconOnekey,
    image: LogoOnekey,
    rcSvg: RcLogoOnekey,
    maybeSvg: LogoOnekey,
    // connectType: BRAND_WALLET_CONNECT_TYPE.OneKeyConnect,
    connectType: BRAND_WALLET_CONNECT_TYPE.QRCodeBase,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
  },
  [WALLET_BRAND_TYPES.TP]: {
    id: 7,
    name: 'TokenPocket',
    brand: WALLET_BRAND_TYPES.TP,
    icon: IconTokenpocket,
    lightIcon: IconTokenpocket,
    image: LogoTp,
    rcSvg: RcLogoTp,
    maybeSvg: LogoTp,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
  },
  [WALLET_BRAND_TYPES.TREZOR]: {
    id: 8,
    name: 'Trezor',
    brand: WALLET_BRAND_TYPES.TREZOR,
    icon: IconTrezor,
    lightIcon: IconTrezor,
    image: LogoTrezor,
    rcSvg: RcLogoTrezor,
    maybeSvg: LogoTrezor,
    connectType: BRAND_WALLET_CONNECT_TYPE.TrezorConnect,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
  },
  [WALLET_BRAND_TYPES.TRUSTWALLET]: {
    id: 9,
    name: 'Trust Wallet',
    brand: WALLET_BRAND_TYPES.TRUSTWALLET,
    icon: IconTrust,
    lightIcon: IconTrust,
    image: LogoTrust,
    rcSvg: RcLogoTrust,
    maybeSvg: LogoTrust,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
  },
  [WALLET_BRAND_TYPES.Rainbow]: {
    id: 21,
    name: 'Rainbow',
    brand: WALLET_BRAND_TYPES.Rainbow,
    icon: LogoRainbow,
    lightIcon: LogoRainbow,
    image: LogoRainbow,
    rcSvg: RcLogoRainbow,
    maybeSvg: LogoRainbow,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
  },
  [WALLET_BRAND_TYPES.Bitkeep]: {
    id: 22,
    name: 'Bitget Wallet',
    brand: WALLET_BRAND_TYPES.Bitkeep,
    icon: LogoBitkeep,
    lightIcon: LogoBitkeep,
    image: LogoBitkeep,
    rcSvg: RcLogoBitkeep,
    maybeSvg: LogoBitkeep,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
  },
  [WALLET_BRAND_TYPES.Zerion]: {
    id: 23,
    name: 'Zerion Wallet',
    brand: WALLET_BRAND_TYPES.Zerion,
    icon: LogoZerion,
    lightIcon: LogoZerion,
    image: LogoZerion,
    rcSvg: RcLogoZerion,
    maybeSvg: LogoZerion,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
  },
  // [WALLET_BRAND_TYPES.Uniswap]: {
  //   id: 24,
  //   name: 'Uniswap Wallet',
  //   brand: WALLET_BRAND_TYPES.Uniswap,
  //   icon: LogoUniswap,
  //   image: LogoUniswap,
  //   connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
  //   category: WALLET_BRAND_CATEGORY.MOBILE,
  // },
  [WALLET_BRAND_TYPES.CoboArgus]: {
    id: 25,
    name: 'Cobo Argus',
    brand: WALLET_BRAND_TYPES.CoboArgus,
    icon: LogoCoboArgus,
    lightIcon: LogoCoboArgus,
    image: LogoCoboArgus,
    rcSvg: RcLogoCoboArgus,
    maybeSvg: LogoCoboArgus,
    connectType: BRAND_WALLET_CONNECT_TYPE.CoboArgusConnect,
    category: WALLET_BRAND_CATEGORY.INSTITUTIONAL,
  },
  [WALLET_BRAND_TYPES.MPCVault]: {
    id: 26,
    name: 'MPCVault',
    brand: WALLET_BRAND_TYPES.MPCVault,
    icon: LogoMPCVault,
    lightIcon: LogoMPCVault,
    image: LogoMPCVault,
    rcSvg: RcLogoMPCVault,
    maybeSvg: LogoMPCVault,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.INSTITUTIONAL,
  },
  [WALLET_BRAND_TYPES.IMTOKENOFFLINE]: {
    id: 27,
    name: 'imToken',
    brand: WALLET_BRAND_TYPES.IMTOKENOFFLINE,
    icon: LogoImtokenOffline,
    lightIcon: LogoImtokenOffline,
    image: LogoImtokenOffline,
    rcSvg: RcLogoImtokenOffline,
    maybeSvg: LogoImtokenOffline,
    connectType: BRAND_WALLET_CONNECT_TYPE.QRCodeBase,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
  },
  [WALLET_BRAND_TYPES.Coinbase]: {
    id: 28,
    name: 'Coinbase',
    brand: WALLET_BRAND_TYPES.Coinbase,
    lightIcon: IconCoinbase,
    icon: IconCoinbase,
    image: IconCoinbase,
    rcSvg: RCIconCoinbase,
    connectType: BRAND_WALLET_CONNECT_TYPE.CoinbaseConnect,
    category: WALLET_BRAND_CATEGORY.MOBILE,
  },
  [WALLET_BRAND_TYPES.IMKEY]: {
    id: 29,
    name: 'imKey',
    brand: WALLET_BRAND_TYPES.IMKEY,
    icon: IconImKey,
    lightIcon: IconImKey,
    image: IconImKey,
    rcSvg: RCIconImKey,
    maybeSvg: IconImKey,
    connectType: BRAND_WALLET_CONNECT_TYPE.ImKeyConnect,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
  },
  [WALLET_BRAND_TYPES.Utila]: {
    id: 30,
    name: 'Utila',
    brand: WALLET_BRAND_TYPES.Utila,
    icon: IconUtila,
    lightIcon: IconUtila,
    image: IconUtila,
    rcSvg: RCIconUtila,
    connectType: BRAND_WALLET_CONNECT_TYPE.WalletConnect,
    category: WALLET_BRAND_CATEGORY.INSTITUTIONAL,
  },
  [WALLET_BRAND_TYPES.NGRAVEZERO]: {
    id: 31,
    name: 'NGRAVE ZERO',
    brand: WALLET_BRAND_TYPES.NGRAVEZERO,
    icon: IconNgrave,
    lightIcon: IconNgrave,
    image: IconNgrave,
    rcSvg: RCIconNgrave,
    maybeSvg: IconNgrave,
    connectType: BRAND_WALLET_CONNECT_TYPE.QRCodeBase,
    category: WALLET_BRAND_CATEGORY.HARDWARE,
  },
};

export const KEYRING_ICONS = {
  [KEYRING_CLASS.MNEMONIC]: IconMnemonicInk,
  [KEYRING_CLASS.PRIVATE_KEY]: IconPrivateKeyInk,
  [KEYRING_CLASS.WATCH]: IconWatchInk,
  [HARDWARE_KEYRING_TYPES.BitBox02.type]: IconBitBox02,
  [HARDWARE_KEYRING_TYPES.Ledger.type]: LogoLedgerWhite,
  [HARDWARE_KEYRING_TYPES.Onekey.type]: LogoOnekey,
  [HARDWARE_KEYRING_TYPES.Trezor.type]: IconTrezor24,
  [HARDWARE_KEYRING_TYPES.GridPlus.type]: IconGridPlus,
  [HARDWARE_KEYRING_TYPES.ImKey.type]: IconImKey,
  [KEYRING_TYPE.Whitelist]: IconWhiteListWhite,
  // [HARDWARE_KEYRING_TYPES.Keystone.type]: LogoKeystone,
} as const;

type BasicKeyringNames = {
  [P in keyof typeof KEYRING_TYPE]: typeof KEYRING_TYPE[P];
};
export type BasicKeyrings = BasicKeyringNames[keyof BasicKeyringNames];

type HardwareKeyringNames = {
  [P in keyof typeof HARDWARE_KEYRING_TYPES]: typeof HARDWARE_KEYRING_TYPES[P]['type'];
};
export type HardwareKeyrings = HardwareKeyringNames[keyof HardwareKeyringNames];

export type KeyringWithIcon = keyof typeof KEYRING_ICONS;

export const KEYRING_ICONS_WHITE: Record<KeyringWithIcon, string> = {
  [KEYRING_CLASS.MNEMONIC]: IconMnemonicWhite,
  [KEYRING_CLASS.PRIVATE_KEY]: IconPrivateKeyWhite,
  [KEYRING_CLASS.WATCH]: IconWatchWhite,
  [HARDWARE_KEYRING_TYPES.BitBox02.type]: IconBitBox02,
  [HARDWARE_KEYRING_TYPES.Ledger.type]: LogoLedgerWhite,
  [HARDWARE_KEYRING_TYPES.Onekey.type]: LogoOnekey,
  [HARDWARE_KEYRING_TYPES.Trezor.type]: IconTrezor24,
  [HARDWARE_KEYRING_TYPES.GridPlus.type]: IconGridPlus,
  [HARDWARE_KEYRING_TYPES.ImKey.type]: IconImKey,
  [KEYRING_TYPE.Whitelist]: IconWhiteListDark,
  // [HARDWARE_KEYRING_TYPES.Keystone.type]: LogoKeystone,
};

export const KEYRING_PURPLE_LOGOS = {
  [KEYRING_CLASS.MNEMONIC]: IconMnemonicInk,
  [KEYRING_CLASS.PRIVATE_KEY]: IconPrivateKeyInk,
  [KEYRING_CLASS.WATCH]: IconWatchInk,
};

export const KEYRINGS_LOGOS: Record<KeyringWithIcon, string> = {
  [KEYRING_CLASS.MNEMONIC]: IconMnemonicWhite,
  [KEYRING_CLASS.PRIVATE_KEY]: LogoPrivateKey,
  [KEYRING_CLASS.WATCH]: IconWatchWhite,
  [HARDWARE_KEYRING_TYPES.BitBox02.type]: IconBitBox02WithBorder,
  [HARDWARE_KEYRING_TYPES.Ledger.type]: LogoLedgerWhite,
  [HARDWARE_KEYRING_TYPES.Onekey.type]: IconOneKey18,
  [HARDWARE_KEYRING_TYPES.Trezor.type]: IconTrezor24Border,
  [HARDWARE_KEYRING_TYPES.GridPlus.type]: IconGridPlus,
  [HARDWARE_KEYRING_TYPES.ImKey.type]: IconImKey,

  [KEYRING_TYPE.Whitelist]: IconWhiteListWhite,
  // [HARDWARE_KEYRING_TYPES.Keystone.type]: LogoKeystone,
};

type NextKeyringIconType = {
  dataDark: ThemeIconType & string;
  rcDark: Exclude<ThemeIconType, string>;
  dataLight: ThemeIconType & string;
  rcLight: Exclude<ThemeIconType, string>;
};

export const NEXT_KEYRING_ICONS = {
  [KEYRING_CLASS.MNEMONIC]: {
    dataLight: KEYRING_ICONS_WHITE[KEYRING_CLASS.MNEMONIC],
    dataDark: KEYRING_ICONS[KEYRING_CLASS.MNEMONIC],
    rcLight: RcIconMnemonicWhite,
    rcDark: RcIconMnemonicInk,
  } as NextKeyringIconType,
  [KEYRING_CLASS.PRIVATE_KEY]: {
    dataLight: KEYRING_ICONS_WHITE[KEYRING_CLASS.PRIVATE_KEY],
    dataDark: KEYRING_ICONS[KEYRING_CLASS.PRIVATE_KEY],
    rcLight: RcIconPrivateKeyWhite,
    rcDark: RcIconPrivateKeyInk,
  } as NextKeyringIconType,
  [KEYRING_CLASS.WATCH]: {
    dataLight: KEYRING_ICONS_WHITE[KEYRING_CLASS.WATCH],
    dataDark: KEYRING_ICONS[KEYRING_CLASS.WATCH],
    rcLight: RcIconWatchWhite,
    rcDark: RcIconWatchInk,
  } as NextKeyringIconType,
  [HARDWARE_KEYRING_TYPES.BitBox02.type]: {
    dataLight: KEYRING_ICONS_WHITE[HARDWARE_KEYRING_TYPES.BitBox02.type],
    dataDark: KEYRING_ICONS[HARDWARE_KEYRING_TYPES.BitBox02.type],
    rcLight: RcIconBitBox02,
    rcDark: RcIconBitBox02,
  } as NextKeyringIconType,
  [HARDWARE_KEYRING_TYPES.Ledger.type]: {
    dataLight: KEYRING_ICONS_WHITE[HARDWARE_KEYRING_TYPES.Ledger.type],
    dataDark: KEYRING_ICONS[HARDWARE_KEYRING_TYPES.Ledger.type],
    rcLight: RcLogoLedgerWhite,
    rcDark: RcLogoLedgerWhite,
  } as NextKeyringIconType,
  [HARDWARE_KEYRING_TYPES.Onekey.type]: {
    dataLight: KEYRING_ICONS_WHITE[HARDWARE_KEYRING_TYPES.Onekey.type],
    dataDark: KEYRING_ICONS[HARDWARE_KEYRING_TYPES.Onekey.type],
    rcLight: RcLogoOnekey,
    rcDark: RcLogoOnekey,
  } as NextKeyringIconType,
  [HARDWARE_KEYRING_TYPES.Trezor.type]: {
    dataLight: KEYRING_ICONS_WHITE[HARDWARE_KEYRING_TYPES.Trezor.type],
    dataDark: KEYRING_ICONS[HARDWARE_KEYRING_TYPES.Trezor.type],
    rcLight: RcIconTrezor24,
    rcDark: RcIconTrezor24,
  } as NextKeyringIconType,
  [HARDWARE_KEYRING_TYPES.GridPlus.type]: {
    dataLight: KEYRING_ICONS_WHITE[HARDWARE_KEYRING_TYPES.GridPlus.type],
    dataDark: KEYRING_ICONS[HARDWARE_KEYRING_TYPES.GridPlus.type],
    rcLight: RcIconGridPlus,
    rcDark: RcIconGridPlus,
  } as NextKeyringIconType,
  [HARDWARE_KEYRING_TYPES.ImKey.type]: {
    dataLight: KEYRING_ICONS_WHITE[HARDWARE_KEYRING_TYPES.ImKey.type],
    dataDark: KEYRING_ICONS[HARDWARE_KEYRING_TYPES.ImKey.type],
    rcLight: RCIconImKey,
    rcDark: RCIconImKey,
  } as NextKeyringIconType,
};

export const RC_KEYRING_ICONS = Object.entries(NEXT_KEYRING_ICONS).reduce(
  (acc, [keyringClass, keyringIcons]) => {
    acc[keyringClass] = keyringIcons;
    return acc;
  },
  {} as {
    [P in keyof typeof NEXT_KEYRING_ICONS]: {
      rcDark: typeof NEXT_KEYRING_ICONS[P]['rcDark'];
      rcLight: typeof NEXT_KEYRING_ICONS[P]['rcLight'];
    };
  }
);

export const NOT_CLOSE_UNFOCUS_LIST: string[] = [
  WALLET_BRAND_TYPES.AMBER,
  WALLET_BRAND_TYPES.COBO,
];

export const SPECIFIC_TEXT_BRAND = {
  [WALLET_BRAND_TYPES.JADE]: {
    i18nKey: 'WatchGuideStep2JADE',
  },
};

export const SORT_WEIGHT = {
  [KEYRING_TYPE.HdKeyring]: 1,
  [KEYRING_TYPE.SimpleKeyring]: 2,
  [KEYRING_TYPE.HardwareKeyring]: 3,
  [KEYRING_TYPE.WalletConnectKeyring]: 4,
  [KEYRING_TYPE.GnosisKeyring]: 5,
  [KEYRING_TYPE.WatchAddressKeyring]: 999,
};

export const GASPRICE_RANGE = ensureChainHashValid({
  [CHAINS_ENUM.ETH]: [0, 20000],
  [CHAINS_ENUM.BOBA]: [0, 20000],
  [CHAINS_ENUM.OP]: [0, 20000],
  [CHAINS_ENUM.BASE]: [0, 20000],
  [CHAINS_ENUM.ZORA]: [0, 20000],
  [CHAINS_ENUM.ERA]: [0, 20000],
  [CHAINS_ENUM.KAVA]: [0, 20000],
  [CHAINS_ENUM.ARBITRUM]: [0, 20000],
  [CHAINS_ENUM.AURORA]: [0, 20000],
  [CHAINS_ENUM.BSC]: [0, 20000],
  [CHAINS_ENUM.AVAX]: [0, 40000],
  [CHAINS_ENUM.POLYGON]: [0, 100000],
  [CHAINS_ENUM.FTM]: [0, 100000],
  [CHAINS_ENUM.GNOSIS]: [0, 500000],
  [CHAINS_ENUM.OKT]: [0, 50000],
  [CHAINS_ENUM.HECO]: [0, 100000],
  [CHAINS_ENUM.CELO]: [0, 100000],
  [CHAINS_ENUM.MOVR]: [0, 50000],
  [CHAINS_ENUM.CRO]: [0, 500000],
  [CHAINS_ENUM.BTT]: [0, 20000000000],
  [CHAINS_ENUM.METIS]: [0, 50000],
});

export const HDPaths = {
  [HARDWARE_KEYRING_TYPES.Ledger.type]: [
    { name: 'Ledger Live', value: "m/44'/60'/0'/0/0" },
    { name: 'Legacy (MEW / MyCrypto)', value: "m/44'/60'/0'" },
    { name: 'BIP44 Standard', value: "m/44'/60'/0'/0" },
  ],
};

export enum KEYRING_CATEGORY {
  Mnemonic = 'Mnemonic',
  PrivateKey = 'PrivateKey',
  WatchMode = 'WatchMode',
  Contract = 'Contract',
  Hardware = 'Hardware',
  WalletConnect = 'WalletConnect',
}

export const KEYRING_CATEGORY_MAP = {
  [KEYRING_CLASS.MNEMONIC]: KEYRING_CATEGORY.Mnemonic,
  [KEYRING_CLASS.PRIVATE_KEY]: KEYRING_CATEGORY.PrivateKey,
  [KEYRING_CLASS.WATCH]: KEYRING_CATEGORY.WatchMode,
  [KEYRING_CLASS.HARDWARE.LEDGER]: KEYRING_CATEGORY.Hardware,
  [KEYRING_CLASS.HARDWARE.ONEKEY]: KEYRING_CATEGORY.Hardware,
  [KEYRING_CLASS.HARDWARE.TREZOR]: KEYRING_CATEGORY.Hardware,
  [KEYRING_CLASS.HARDWARE.BITBOX02]: KEYRING_CATEGORY.Hardware,
  [KEYRING_CLASS.HARDWARE.KEYSTONE]: KEYRING_CATEGORY.Hardware,
  [KEYRING_CLASS.HARDWARE.NGRAVEZERO]: KEYRING_CATEGORY.Hardware,
  [KEYRING_CLASS.HARDWARE.GRIDPLUS]: KEYRING_CATEGORY.Hardware,
  [KEYRING_CLASS.WALLETCONNECT]: KEYRING_CATEGORY.WalletConnect,
  [KEYRING_CLASS.Coinbase]: KEYRING_CATEGORY.WalletConnect,
  [KEYRING_CLASS.GNOSIS]: KEYRING_CATEGORY.Contract,
  [KEYRING_CLASS.HARDWARE.IMKEY]: KEYRING_CATEGORY.Hardware,
};

export const SWAP_FEE_PRECISION = 1e5;

export const DEFAULT_GAS_LIMIT_RATIO = 1.5;

export const SAFE_GAS_LIMIT_RATIO = {
  '1284': 2,
  '1285': 2,
  '1287': 2,
};

export const SAFE_GAS_LIMIT_BUFFER = {
  '996': 0.86,
  '49088': 0.86,
  '3068': 0.86,
};

export const DEFAULT_GAS_LIMIT_BUFFER = 0.95;

export const GAS_TOP_UP_ADDRESS = '0x7559e1bbe06e94aeed8000d5671ed424397d25b5';
export const GAS_TOP_UP_PAY_ADDRESS =
  '0x1f1f2bf8942861e6194fda1c0a9f13921c0cf117';
export const FREE_GAS_ADDRESS = '0x76dd65529dc6c073c1e0af2a5ecc78434bdbf7d9';

export const GAS_TOP_UP_SUPPORT_TOKENS: Record<string, string[]> = {
  arb: [
    '0xaf88d065e77c8cc2239327c5edb3a432268e5831',
    '0xda10009cbd5d07dd0cecc66161fc93d7c9000da1',
    '0xfd086bc7cd5c481dcc9c85ebe478a1c0b69fcbb9',
    'arb',
  ],
  astar: ['astar'],
  aurora: ['aurora'],
  avax: ['avax'],
  base: ['0x833589fcd6edb6e08f4c7c32d4f71b54bda02913', 'base'],
  boba: ['boba'],
  bsc: [
    '0x1af3f329e8be154074d8769d1ffa4ee058b1dbc3',
    '0x2170ed0880ac9a755fd29b2688956bd959f933f8',
    '0x55d398326f99059ff775485246999027b3197955',
    '0x8ac76a51cc950d9822d68b83fe1ad97b32cd580d',
    '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c',
    'bsc',
  ],
  canto: ['canto'],
  celo: ['celo'],
  cro: ['0x5c7f8a570d578ed84e63fdfa7b1ee72deae1ae23', 'cro'],
  era: ['era'],
  eth: [
    '0x6b175474e89094c44da98b954eedeac495271d0f',
    '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
    '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2',
    '0xdac17f958d2ee523a2206206994597c13d831ec7',
    'eth',
  ],
  evmos: ['evmos'],
  ftm: ['0x21be370d5312f44cb42ce377bc9b8a0cef1a4c83', 'ftm'],
  hmy: ['hmy'],
  kava: ['kava'],
  kcc: ['kcc'],
  linea: ['linea'],
  matic: [
    '0x0d500b1d8e8ef31e21c99d1db9a6444d3adf1270',
    '0x3c499c542cef5e3811e1192ce70d8cc03d5c3359',
    '0x8f3cf7ad23cd3cadbd9735aff958023239c6a063',
    '0xc2132d05d31c914a87c6611c10748aeb04b58e8f',
    'matic',
  ],
  metis: ['metis'],
  mnt: ['mnt'],
  mobm: ['mobm'],
  movr: ['movr'],
  nova: ['nova'],
  okt: ['okt'],
  op: [
    '0x0b2c639c533813f4aa9d7837caf62653d097ff85',
    '0x94b008aa00579c1307b0ef2c499ad98a8ce58e58',
    '0xda10009cbd5d07dd0cecc66161fc93d7c9000da1',
    'op',
  ],
  opbnb: ['opbnb'],
  pls: ['pls'],
  pze: ['pze'],
  scrl: ['scrl'],
  xdai: ['xdai'],
};

export const EXTERNAL_RESOURCE_DOMAIN_BLACK_LIST = ['5degrees.io'];

export const ALIAS_ADDRESS = {
  [GAS_TOP_UP_ADDRESS]: 'Rabby Gas Top Up',
  [GAS_TOP_UP_PAY_ADDRESS]: 'Rabby Gas Top Up',
  [FREE_GAS_ADDRESS]: 'Free Gas',
};

// non-opstack L2 chains
export const L2_ENUMS = [
  CHAINS_ENUM.ARBITRUM,
  CHAINS_ENUM.AURORA,
  CHAINS_ENUM.NOVA,
  CHAINS_ENUM.BOBA,
  CHAINS_ENUM.MANTLE,
  CHAINS_ENUM.LINEA,
  CHAINS_ENUM.MANTA,
  CHAINS_ENUM.SCRL,
  CHAINS_ENUM.ERA,
  CHAINS_ENUM.PZE,
  CHAINS_ENUM.MANTA,
  CHAINS_ENUM.OP,
  CHAINS_ENUM.BASE,
  CHAINS_ENUM.ZORA,
  CHAINS_ENUM.OPBNB,
  CHAINS_ENUM.BLAST,
  CHAINS_ENUM.MODE,
  'DBK',
  'MINT',
  'CYBER',
  'KATANA',
  'WORLD',
  'INK',
  'SONEIUM',
];

// opstack L2 chains
export const OP_STACK_ENUMS = [
  CHAINS_ENUM.OP,
  CHAINS_ENUM.BASE,
  CHAINS_ENUM.ZORA,
  CHAINS_ENUM.OPBNB,
  CHAINS_ENUM.BLAST,
  CHAINS_ENUM.MODE,
  'DBK',
  'MINT',
  'CYBER',
  'KATANA',
  'WORLD',
  'INK',
  'SONEIUM',
];

export const ARB_LIKE_L2_CHAINS = [CHAINS_ENUM.ARBITRUM, CHAINS_ENUM.AURORA];

export const CAN_NOT_SPECIFY_INTRINSIC_GAS_CHAINS = [...L2_ENUMS];

export const CAN_ESTIMATE_L1_FEE_CHAINS = [
  ...OP_STACK_ENUMS,
  CHAINS_ENUM.SCRL,
  ...ARB_LIKE_L2_CHAINS,
  CHAINS_ENUM.PZE,
  CHAINS_ENUM.ERA,
  CHAINS_ENUM.LINEA,
  'CITREA',
];

export const SecurityEngineLevelOrder = [
  Level.FORBIDDEN,
  Level.DANGER,
  Level.WARNING,
  Level.SAFE,
  null,
  Level.ERROR,
  'proceed',
];

export const SecurityEngineLevel = {
  [Level.SAFE]: {
    color: '#27C193',
    icon: IconSafe,
    text: 'Safe',
  },
  [Level.WARNING]: {
    color: '#FFB020',
    icon: IconWarning,
    text: 'Warning',
  },
  [Level.DANGER]: {
    color: '#EC5151',
    icon: IconDanger,
    text: 'Danger',
  },
  [Level.FORBIDDEN]: {
    color: '#AF160E',
    icon: IconForbidden,
    text: 'Forbidden',
  },
  [Level.ERROR]: {
    color: '#B4BDCC',
    icon: IconError,
    text: 'Security engine failed',
  },
  closed: {
    color: '#B4BDCC',
    icon: IconClosed,
    text: 'Closed',
  },
  proceed: {
    color: '#707280',
    icon: IconProceed,
    text: 'Proceed',
  },
};

declare global {
  interface Window {
    __is_rd__?: boolean;
  }
}

export const IS_RD = typeof window === 'undefined' ? false : window.__is_rd__;

export const BRAND_ALIAN_TYPE_TEXT = {
  [KEYRING_TYPE.HdKeyring]: 'Seed Phrase',
  [KEYRING_TYPE.SimpleKeyring]: 'Private Key',
  [KEYRING_TYPE.WatchAddressKeyring]: 'Watch-only',
  [KEYRING_CLASS.HARDWARE.LEDGER]: 'Ledger',
  [KEYRING_CLASS.HARDWARE.TREZOR]: 'Trezor',
  [KEYRING_CLASS.HARDWARE.ONEKEY]: 'OneKey',
  [WALLET_BRAND_TYPES.ONEKEY]: 'Onekey QR',
  [KEYRING_CLASS.HARDWARE.BITBOX02]: 'BitBox02',
  [KEYRING_CLASS.GNOSIS]: 'Safe',
  [KEYRING_CLASS.HARDWARE.GRIDPLUS]: 'GridPlus',
  [KEYRING_CLASS.HARDWARE.KEYSTONE]: 'Keystone',
  [KEYRING_CLASS.HARDWARE.NGRAVEZERO]: 'NGRAVE ZERO',
  [WALLET_BRAND_TYPES.TP]: WALLET_BRAND_CONTENT.TP.name,
  [WALLET_BRAND_TYPES.METAMASK]: WALLET_BRAND_CONTENT.MetaMask.name,
  [WALLET_BRAND_TYPES.IMTOKEN]: WALLET_BRAND_CONTENT.IMTOKEN.name,
  [WALLET_BRAND_TYPES.MATHWALLET]: WALLET_BRAND_CONTENT.MATHWALLET.name,
  [WALLET_BRAND_TYPES.TRUSTWALLET]: WALLET_BRAND_CONTENT.TRUSTWALLET.name,
  [KEYRING_CLASS.Coinbase]: WALLET_BRAND_CONTENT.Coinbase.name,
  [KEYRING_CLASS.HARDWARE.IMKEY]: 'imKey',
};

export const COBO_ARGUS_SUPPORT_CHAINS = ensureChainListValid([
  CHAINS_ENUM.ETH,
  CHAINS_ENUM.OP,
  CHAINS_ENUM.BSC,
  CHAINS_ENUM.POLYGON,
  CHAINS_ENUM.ARBITRUM,
  CHAINS_ENUM.AVAX,
  CHAINS_ENUM.BASE,
  CHAINS_ENUM.MANTLE,
  CHAINS_ENUM.GNOSIS,
  CHAINS_ENUM.SCRL,
  CHAINS_ENUM.MANTA,
  CHAINS_ENUM.MODE,
]);

export const WALLET_SORT_SCORE = [
  //mobile
  WALLET_BRAND_TYPES.METAMASK,
  WALLET_BRAND_TYPES.TRUSTWALLET,
  WALLET_BRAND_TYPES.TP,
  WALLET_BRAND_TYPES.IMTOKEN,
  WALLET_BRAND_TYPES.MATHWALLET,
  WALLET_BRAND_TYPES.Rainbow,
  WALLET_BRAND_TYPES.Bitkeep,
  WALLET_BRAND_TYPES.Zerion,
  // WALLET_BRAND_TYPES.Uniswap,
  WALLET_BRAND_TYPES.WALLETCONNECT,
  //hardware wallet
  WALLET_BRAND_TYPES.LEDGER,
  WALLET_BRAND_TYPES.TREZOR,
  WALLET_BRAND_TYPES.GRIDPLUS,
  WALLET_BRAND_TYPES.ONEKEY,
  WALLET_BRAND_TYPES.KEYSTONE,
  WALLET_BRAND_TYPES.NGRAVEZERO,
  WALLET_BRAND_TYPES.BITBOX02,
  WALLET_BRAND_TYPES.COOLWALLET,
  WALLET_BRAND_TYPES.AIRGAP,
  WALLET_BRAND_TYPES.IMTOKENOFFLINE,
  WALLET_BRAND_TYPES.Coinbase,
  //institutional
  WALLET_BRAND_TYPES.GNOSIS,
  WALLET_BRAND_TYPES.CoboArgus,
  WALLET_BRAND_TYPES.AMBER,
  WALLET_BRAND_TYPES.FIREBLOCKS,
  WALLET_BRAND_TYPES.JADE,
  WALLET_BRAND_TYPES.MPCVault,
].reduce((pre, now, i) => {
  pre[now] = i + 1;
  return pre;
}, {} as { [k: string]: number });

export const SWAP_FEE_ADDRESS = '0x39041F1B366fE33F9A5a79dE5120F2Aee2577ebc';

export const ETH_USDT_CONTRACT = '0xdac17f958d2ee523a2206206994597c13d831ec7';

export const DEX = {
  [DEX_ENUM.ZEROXAPI]: {
    id: DEX_ENUM.ZEROXAPI,
    logo: Logo0X,
    name: '0x',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.ZEROXAPI],
  },
  [DEX_ENUM.PARASWAP]: {
    id: DEX_ENUM.PARASWAP,
    logo: LogoParaswap,
    name: 'ParaSwap',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.PARASWAP],
  },
  [DEX_ENUM.ONEINCH]: {
    id: DEX_ENUM.ONEINCH,
    logo: Logo1inch,
    name: '1inch',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.ONEINCH],
  },

  [DEX_ENUM.OPENOCEAN]: {
    id: DEX_ENUM.OPENOCEAN,
    logo: LogoOpenOcean,
    name: 'De¹',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.OPENOCEAN],
  },
  [DEX_ENUM.KYBERSWAP]: {
    id: DEX_ENUM.KYBERSWAP,
    logo: LogoKyberSwap,
    name: 'KyberSwap',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.KYBERSWAP],
  },
  [DEX_ENUM.PARASWAPV6]: {
    id: DEX_ENUM.PARASWAPV6,
    logo: LogoParaswap,
    name: 'ParaSwap',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.PARASWAPV6],
  },
  [DEX_ENUM.ODOS]: {
    id: DEX_ENUM.ODOS,
    logo: LogoOdos,
    name: 'Odos',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.ODOS],
  },
  [DEX_ENUM.ZEROXAPIV2]: {
    id: DEX_ENUM.ZEROXAPIV2,
    logo: Logo0X,
    name: '0x',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.ZEROXAPIV2],
  },
  [DEX_ENUM.MAGPIE]: {
    id: DEX_ENUM.MAGPIE,
    logo: LogoMagpie,
    name: 'Fly',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.MAGPIE],
  },
  [DEX_ENUM.SUSHI]: {
    id: DEX_ENUM.SUSHI,
    logo: LogoSushi,
    name: 'Sushi',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.SUSHI],
  },
  [DEX_ENUM.UNI]: {
    id: DEX_ENUM.UNI,
    logo: LogoUniswap,
    name: 'Uniswap',
    chains: DEX_SUPPORT_CHAINS[DEX_ENUM.UNI],
  },
};

export const DEX_WITH_WRAP = {
  ...DEX,
  [DEX_ENUM.WRAPTOKEN]: {
    logo: LogoTokenDefault,
    name: 'Wrap Contract',
    chains: DEX_SUPPORT_CHAINS.WrapToken,
  },
};

export const CEX = {
  // binance: {
  //   id: 'binance',
  //   name: 'Binance',
  //   logo: LogoBinance,
  // },
  // coinbase: {
  //   id: 'coinbase',
  //   name: 'Coinbase',
  //   logo: LogoCoinbase,
  // },
  // okex: {
  //   id: 'okex',
  //   name: 'OKX',
  //   logo: LogoOkx,
  // },
};

export const SWAP_SUPPORT_CHAINS = Array.from(
  new Set(Object.values(DEX_SUPPORT_CHAINS).flat())
);

export enum SIGN_PERMISSION_TYPES {
  MAINNET_AND_TESTNET = 'MAINNET_AND_TESTNET',
  TESTNET = 'TESTNET',
}
export const SIGN_PERMISSION_OPTIONS = [
  {
    label: 'Mainnet & Testnet',
    value: SIGN_PERMISSION_TYPES.MAINNET_AND_TESTNET,
  },
  {
    label: 'Only Testnets',
    value: SIGN_PERMISSION_TYPES.TESTNET,
  },
];

export enum CANCEL_TX_TYPE {
  QUICK_CANCEL = 'QUICK_CANCEL',
  ON_CHAIN_CANCEL = 'ON_CHAIN_CANCEL',
  REMOVE_LOCAL_PENDING_TX = 'REMOVE_LOCAL_PENDING_TX',
}
export const REJECT_SIGN_TEXT_KEYRINGS = [KEYRING_TYPE.CoboArgusKeyring];

export enum DARK_MODE_TYPE {
  'light' = 0,
  'dark' = 1,
  'system' = 2,
}

export const ThemeModes = [
  {
    code: DARK_MODE_TYPE.system,
    name: 'System',
  },
  {
    code: DARK_MODE_TYPE.light,
    name: 'Light',
  },
  {
    code: DARK_MODE_TYPE.dark,
    name: 'Dark',
  },
];

export const imKeyUSBVendorId = 0x096e;

export const DBK_CHAIN_ID = 20240603;

export const DBK_CHAIN_BRIDGE_CONTRACT =
  '0x28f1b9F457CB51E0af56dff1d11CD6CEdFfD1977';
export const DBK_NFT_CONTRACT_ADDRESS =
  '0x633b7472E1641D59334886a7692107D6332B1ff0';

export const SELF_HOST_SAFE_NETWORKS = [
  '1',
  '56',
  '42161',
  '137',
  '10',
  '8453',
];
export const CUSTOM_RPC_ENABLED = true;
