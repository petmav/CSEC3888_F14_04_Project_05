import { last } from 'lodash';
import { createPersistStore } from 'background/utils';
import { getRandomBytesSync } from 'ethereum-cryptography/random.js';
import { secp256k1 } from 'ethereum-cryptography/secp256k1.js';
import { bytesToHex, publicToAddress, hexToBytes } from '@ethereumjs/util';
import { keyringService } from '.';
import { SendApproveParams } from '@rabby-wallet/hyperliquid-sdk';
import { Account } from '@/background/service/preference';
import eventBus from '@/eventBus';
import { EVENTS } from '@/constant';
import {
  DEFAULT_PERPS_ORDER_CONFIRMATIONS,
  isPerpsOrderConfirmType,
} from '@/constant/perps';
import type {
  PerpsOrderConfirmations,
  PerpsOrderConfirmType,
} from '@/constant/perps';
export interface AgentWalletInfo {
  vault: string;
  preference: {
    agentAddress: string;
    approveSignatures: ApproveSignatures;
  };
}

interface StoreAccount {
  address: string;
  type: string;
  brandName: string;
}

export type ApproveSignatures = (SendApproveParams & {
  type: 'approveAgent' | 'approveBuilderFee';
})[];

export type PerpsTpslModePreference = 'pnl' | 'roi';
export type PerpsTpslModePreferences = Record<
  'tp' | 'sl',
  PerpsTpslModePreference
>;

const DEFAULT_TPSL_MODE_PREFERENCES: PerpsTpslModePreferences = {
  tp: 'pnl',
  sl: 'pnl',
};

export interface PerpsServiceStore {
  agentVaults: string; // encrypted JSON string of {[address: string]: string}
  agentPreferences: {
    [address: string]: {
      agentAddress: string;
      approveSignatures: ApproveSignatures;
    };
  };
  inviteConfig: {
    [address: string]: {
      lastInvitedAt?: number;
      lastConnectedAt?: number;
    };
  };
  currentAccount: StoreAccount | null;
  lastUsedAccount: StoreAccount | null;
  hasDoneNewUserProcess: boolean;
  hasDismissedNewUserGuideV2: boolean;
  favoritedCoins: string[];
  marginModePreferences: Record<string, 'cross' | 'isolated'>;
  soundEnabled: boolean;
  marketSlippage: number; // 0-1, default 0.05 (5%)
  quoteUnit: 'base' | 'usd';
  firstOpenPerpsNeedDark: boolean;
  selectedCoin: string;
  skipMarketCloseConfirm: boolean;
  candleInterval: string;
  tpslModePreferences: PerpsTpslModePreferences;
  orderConfirmations: PerpsOrderConfirmations;
  showPopularTradings: boolean;
}
export interface PerpsServiceMemoryState {
  agentWallets: {
    // key is master wallet address
    [address: string]: AgentWalletInfo;
  };
  unlockPromise: Promise<void> | null;
}

class PerpsService {
  private store?: PerpsServiceStore;
  private memoryState: PerpsServiceMemoryState = {
    agentWallets: {},
    unlockPromise: null,
  };

  init = async () => {
    this.store = await createPersistStore<PerpsServiceStore>({
      name: 'perps',
      template: {
        agentVaults: '',
        agentPreferences: {},
        inviteConfig: {},
        currentAccount: null,
        // no clear account , just cache for last used
        lastUsedAccount: null,
        hasDoneNewUserProcess: false,
        hasDismissedNewUserGuideV2: false,
        favoritedCoins: [],
        marginModePreferences: {},
        marketSlippage: 0.05, // default 5%
        soundEnabled: true,
        quoteUnit: 'base',
        firstOpenPerpsNeedDark: true,
        selectedCoin: 'BTC',
        skipMarketCloseConfirm: false,
        candleInterval: '15M',
        tpslModePreferences: DEFAULT_TPSL_MODE_PREFERENCES,
        orderConfirmations: DEFAULT_PERPS_ORDER_CONFIRMATIONS,
        showPopularTradings: true,
      },
    });

    this.memoryState.agentWallets = {};
  };

  setHasDoneNewUserProcess = async (hasDone: boolean) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store.hasDoneNewUserProcess = hasDone;
  };

  getHasDoneNewUserProcess = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.hasDoneNewUserProcess;
  };

  setHasDismissedNewUserGuideV2 = async (dismissed: boolean) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store.hasDismissedNewUserGuideV2 = dismissed;
  };

  getHasDismissedNewUserGuideV2 = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.hasDismissedNewUserGuideV2;
  };

  setSendApproveAfterDeposit = async (
    masterAddress: string,
    approveSignatures: ApproveSignatures
  ) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }

    if (!masterAddress) {
      console.error('masterAddress is required');
      return;
    }

    const normalizedAddress = masterAddress.toLowerCase();

    // Update store preferences
    const existingPreference = this.store.agentPreferences[
      normalizedAddress
    ] || {
      agentAddress: '',
      approveSignatures: [],
    };

    this.store.agentPreferences[normalizedAddress] = {
      ...existingPreference,
      approveSignatures,
    };

    // Update memory state if wallet exists
    if (this.memoryState.agentWallets[normalizedAddress]) {
      this.memoryState.agentWallets[
        normalizedAddress
      ].preference.approveSignatures = approveSignatures;
    }
  };

  getSendApproveAfterDeposit = async (masterAddress: string) => {
    const normalizedAddress = masterAddress.toLowerCase();
    const agentWallet = this.memoryState.agentWallets[normalizedAddress];

    if (!agentWallet) {
      console.error('agentWallet not found');
      return null;
    }

    return agentWallet.preference.approveSignatures;
  };

  // Derive the agent address from the vault key, not the stored preference — a
  // concurrent createAgentWallet can desync preference.agentAddress from the
  // vault across the decrypt await in unlockAgentWallets.
  private deriveAgentAddress = (vault: string): string => {
    const privateKey = hexToBytes(
      vault.startsWith('0x') ? vault : `0x${vault}`
    );
    const publicKey = secp256k1.getPublicKey(privateKey, false);
    return bytesToHex(publicToAddress(publicKey, true)).toLowerCase();
  };

  // Agent vaults aren't re-encrypted on password change, so old ciphertext can
  // fail to decrypt. An agent is re-creatable, so on a genuine mismatch (unlocked
  // but still "Incorrect password") drop the stale data and rebuild.
  private safeDecryptAgentVaults = async (): Promise<{
    [address: string]: string;
  }> => {
    if (!this.store?.agentVaults) {
      return {};
    }
    try {
      return await keyringService.decryptWithPassword(
        this.store.agentVaults,
        true,
        'perps'
      );
    } catch (error) {
      // not unlocked yet → password not ready, not a real mismatch
      if (!keyringService.isUnlocked()) {
        throw error;
      }
      // only "Incorrect password" is a real key mismatch; let other errors
      // (corrupted blob, crypto failure) propagate rather than wipe agent data.
      const message = error instanceof Error ? error.message : String(error);
      if (!/incorrect password/i.test(message)) {
        throw error;
      }
      console.warn(
        '[perpsService] failed to decrypt agentVaults while unlocked, resetting stale agent data',
        message
      );
      if (this.store) {
        this.store.agentVaults = '';
        this.store.agentPreferences = {};
      }
      return {};
    }
  };

  unlockAgentWallets = async () => {
    const unlock = async () => {
      if (!this.store) {
        throw new Error('PerpsService not initialized');
      }
      // Decrypt and load agent vaults
      if (this.store.agentVaults) {
        const vaultsMap = await this.safeDecryptAgentVaults();

        // Format data for memory state
        for (const masterAddress in vaultsMap) {
          const privateKey = vaultsMap[masterAddress];
          // empty vault → deriveAgentAddress would throw; skip it.
          if (!privateKey) {
            continue;
          }
          const preference = this.store.agentPreferences[masterAddress] || {
            agentAddress: '',
            approveSignatures: [],
          };
          this.memoryState.agentWallets[masterAddress] = {
            vault: privateKey,
            preference: {
              ...preference,
              // derived from the vault key, not the stale stored preference
              agentAddress: this.deriveAgentAddress(privateKey),
              approveSignatures: preference.approveSignatures || [],
            },
          };
        }
      }
    };
    this.memoryState.unlockPromise = unlock();
    /**
     *  unlock 是一个耗时比较长的任务，所以如果在解锁时立即尝试获取 agentWallet 可能会碰到解锁没有完成的情况
     *  所以这里把 promise 放到内存里，如果有立即读取的需求需要先读一下 promise 的状态
     * */
    this.memoryState.unlockPromise.finally(() => {
      this.memoryState.unlockPromise = null;
    });
  };

  createAgentWallet = async (masterAddress: string) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    const vault = bytesToHex(getRandomBytesSync(32));
    const agentAddress = this.deriveAgentAddress(vault);
    await this.addAgentWallet(masterAddress, vault, {
      agentAddress,
      approveSignatures: [],
    });
    return { agentAddress, vault };
  };

  addAgentWallet = async (
    masterAddress: string,
    vault: string,
    preference: AgentWalletInfo['preference']
  ) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }

    const normalizedAddress = masterAddress.toLowerCase();

    this.memoryState.agentWallets = {
      ...this.memoryState.agentWallets,
      [normalizedAddress]: {
        vault,
        preference,
      },
    };

    const vaultsMap = await this.safeDecryptAgentVaults();

    vaultsMap[normalizedAddress] = vault;

    const encryptedVaults = await keyringService.encryptWithPassword(
      vaultsMap,
      true,
      'perps'
    );

    // Update store
    this.store.agentVaults = encryptedVaults;
    this.store.agentPreferences = {
      ...this.store.agentPreferences,
      [normalizedAddress]: {
        agentAddress: preference.agentAddress,
        approveSignatures: preference.approveSignatures,
      },
    };
  };

  getAgentWallet = async (address: string) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    if (this.memoryState.unlockPromise) {
      await this.memoryState.unlockPromise;
    }

    const normalizedAddress = address.toLowerCase();

    return this.memoryState.agentWallets[normalizedAddress];
  };

  updateAgentWalletPreference = async (
    address: string,
    preference: AgentWalletInfo['preference']
  ) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }

    const normalizedAddress = address.toLowerCase();
    const existingPreference = this.store.agentPreferences[normalizedAddress];

    if (!existingPreference) {
      throw new Error(`Agent wallet not found for address: ${address}`);
    }

    this.store.agentPreferences = {
      ...this.store.agentPreferences,
      [normalizedAddress]: {
        agentAddress: preference.agentAddress,
        approveSignatures: preference.approveSignatures,
      },
    };

    if (this.memoryState.agentWallets[normalizedAddress]) {
      this.memoryState.agentWallets[normalizedAddress].preference = preference;
    }
  };

  setCurrentAccount = async (account: Account | null) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    if (account) {
      this.store.lastUsedAccount = {
        address: account?.address,
        type: account?.type,
        brandName: account?.brandName,
      };
      this.store.currentAccount = {
        address: account.address,
        type: account.type,
        brandName: account.brandName,
      };
    } else {
      this.store.currentAccount = null;
    }
    eventBus.emit(
      EVENTS.PERPS.WIDGET_ACCOUNT_CHANGED,
      account ? account.address : null
    );
  };

  getLastUsedAccount = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.lastUsedAccount;
  };

  getCurrentAccount = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.currentAccount;
  };

  removeAgentWallet = async (address: string) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }

    const normalizedAddress = address.toLowerCase();

    const vaultsMap = await this.safeDecryptAgentVaults();

    delete vaultsMap[normalizedAddress];

    const encryptedVaults = await keyringService.encryptWithPassword(
      vaultsMap,
      true,
      'perps'
    );

    this.store.agentVaults = encryptedVaults;
    const updatedPreferences = { ...this.store.agentPreferences };
    delete updatedPreferences[normalizedAddress];
    this.store.agentPreferences = updatedPreferences;

    const updatedMemoryWallets = { ...this.memoryState.agentWallets };
    delete updatedMemoryWallets[normalizedAddress];
    this.memoryState.agentWallets = updatedMemoryWallets;

    if (
      this.store.currentAccount?.address.toLowerCase() === normalizedAddress
    ) {
      this.store.currentAccount = null;
    }
    if (
      this.store.lastUsedAccount?.address.toLowerCase() === normalizedAddress
    ) {
      this.store.lastUsedAccount = null;
    }
  };

  hasAgentWallet = (address: string) => {
    if (!this.store) {
      return false;
    }

    const normalizedAddress = address.toLowerCase();
    return !!this.memoryState.agentWallets[normalizedAddress];
  };

  getAgentWalletPreference = (address: string) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }

    const normalizedAddress = address.toLowerCase();
    const preference = this.store.agentPreferences[normalizedAddress];

    if (!preference) {
      return null;
    }

    return preference;
  };

  getPerpsFavoritedCoins = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.favoritedCoins || [];
  };

  setPerpsFavoritedCoins = async (coins: string[]) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store.favoritedCoins = coins;
  };

  getPerpsMarginModePreferences = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.marginModePreferences || {};
  };

  setPerpsMarginModePreference = async (
    coin: string,
    mode: 'cross' | 'isolated'
  ) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    if (!coin) return;
    this.store.marginModePreferences = {
      ...(this.store.marginModePreferences || {}),
      [coin]: mode,
    };
  };

  getTpslModePreferences = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return {
      ...DEFAULT_TPSL_MODE_PREFERENCES,
      ...(this.store.tpslModePreferences || {}),
    };
  };

  setTpslModePreference = async (
    side: 'tp' | 'sl',
    mode: PerpsTpslModePreference
  ) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    if (!['tp', 'sl'].includes(side)) return;
    if (!['pnl', 'roi'].includes(mode)) return;

    this.store.tpslModePreferences = {
      ...DEFAULT_TPSL_MODE_PREFERENCES,
      ...(this.store.tpslModePreferences || {}),
      [side]: mode,
    };
  };

  getMarketSlippage = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.marketSlippage ?? 0.05;
  };

  setMarketSlippage = async (slippage: number) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    // Clamp between 0 and 1
    this.store.marketSlippage = Math.max(0, Math.min(1, slippage));
  };

  getSoundEnabled = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.soundEnabled ?? true;
  };

  setSoundEnabled = async (soundEnabled: boolean) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store.soundEnabled = soundEnabled;
  };

  getInviteConfig = async (address: string) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.inviteConfig[address.toLowerCase()];
  };

  setInviteConfig = async (
    address: string,
    config: { lastConnectedAt?: number; lastInvitedAt?: number }
  ) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store.inviteConfig[address.toLowerCase()] = {
      ...this.store.inviteConfig[address.toLowerCase()],
      ...config,
    };
  };

  getQuoteUnit = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.quoteUnit ?? 'base';
  };

  setQuoteUnit = async (quoteUnit: 'base' | 'usd') => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store.quoteUnit = quoteUnit;
  };

  getIsNeedSetDarkTheme = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    if (this.store.firstOpenPerpsNeedDark) {
      this.store.firstOpenPerpsNeedDark = false;
      return true;
    } else {
      return false;
    }
  };

  getSelectedCoin = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.selectedCoin ?? 'BTC';
  };

  setSelectedCoin = async (coin: string) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store.selectedCoin = coin;
  };

  getSkipMarketCloseConfirm = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.skipMarketCloseConfirm ?? false;
  };

  setSkipMarketCloseConfirm = async (skip: boolean) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store.skipMarketCloseConfirm = skip;
  };

  getOrderConfirmations = async (): Promise<PerpsOrderConfirmations> => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    // Spread the defaults first so a store written by an older build (missing
    // types added later) still resolves every key to `true` instead of
    // `undefined`, which would read as "opted out" at the call site.
    return {
      ...DEFAULT_PERPS_ORDER_CONFIRMATIONS,
      ...(this.store.orderConfirmations || {}),
    };
  };

  setOrderConfirmation = async (
    type: PerpsOrderConfirmType,
    enabled: boolean
  ) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    if (!isPerpsOrderConfirmType(type)) return;

    this.store.orderConfirmations = {
      ...DEFAULT_PERPS_ORDER_CONFIRMATIONS,
      ...(this.store.orderConfirmations || {}),
      [type]: enabled,
    };
  };

  getShowPopularTradings = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.showPopularTradings ?? true;
  };

  setShowPopularTradings = async (show: boolean) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store.showPopularTradings = show;
  };

  getCandleInterval = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    return this.store.candleInterval ?? '15M';
  };

  setCandleInterval = async (interval: string) => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store.candleInterval = interval;
  };

  // only test use
  resetStore = async () => {
    if (!this.store) {
      throw new Error('PerpsService not initialized');
    }
    this.store = {
      hasDismissedNewUserGuideV2: false,
      agentVaults: '',
      agentPreferences: {},
      currentAccount: null,
      lastUsedAccount: null,
      hasDoneNewUserProcess: false,
      inviteConfig: {},
      favoritedCoins: [],
      marginModePreferences: {},
      marketSlippage: 0.05,
      soundEnabled: true,
      quoteUnit: 'base',
      firstOpenPerpsNeedDark: true,
      selectedCoin: 'BTC',
      skipMarketCloseConfirm: false,
      candleInterval: '15M',
      tpslModePreferences: DEFAULT_TPSL_MODE_PREFERENCES,
      orderConfirmations: DEFAULT_PERPS_ORDER_CONFIRMATIONS,
      showPopularTradings: true,
    };
    this.memoryState.agentWallets = {};
  };
}

export default new PerpsService();
