import { setPopupIcon } from './../../utils/index';
import { CHAINS } from 'consts';
import {
  permissionService,
  keyringService,
  preferenceService,
} from 'background/service';
import providerController from './controller';
import { findChainByEnum } from '@/utils/chain';
import { appIsDev } from '@/utils/env';
import wallet from '../wallet';
import { metamaskModeService } from '@/background/service/metamaskModeService';
import { ProviderRequest } from './type';
import { ga4 } from '@/utils/ga4';
import { ethErrors } from 'eth-rpc-errors';
import { getOpenInDesktopPolicy } from './openInDesktopPolicy';
import { allowedSiteChain } from '@/utils/redbelly/allowlist';

const TAB_CHECKIN_DEDUPE_MS = 100;
const TAB_CHECKIN_TTL_MS = 2 * 1000;
const lastTabCheckinAt = new Map<string, number>();

const shouldSkipTabCheckin = (origin: string) => {
  const now = Date.now();

  for (const [key, time] of lastTabCheckinAt) {
    if (now - time > TAB_CHECKIN_TTL_MS) {
      lastTabCheckinAt.delete(key);
    }
  }

  const last = lastTabCheckinAt.get(origin) || 0;
  if (now - last < TAB_CHECKIN_DEDUPE_MS) {
    return true;
  }

  lastTabCheckinAt.set(origin, now);
  return false;
};

const networkIdMap: {
  [key: string]: string;
} = {};

const tabCheckin = ({
  data: {
    params: { name, icon },
  },
  session,
  origin,
}) => {
  session.setProp({ origin, name, icon });
  const site = permissionService.getSite(origin);
  if (site) {
    permissionService.updateConnectSite(origin, { ...site, icon, name }, true);
  }
  if (site?.isConnected && !shouldSkipTabCheckin(origin)) {
    ga4.fireEvent('Dapp_Connected', {
      event_category: 'Dapp Usage',
      event_label: origin,
    });
  }
};

const getProviderState = async (req) => {
  const {
    session: { origin },
  } = req;
  const chainEnum = allowedSiteChain(
    permissionService.getWithoutUpdate(origin)?.chain
  );
  const isUnlocked = keyringService.memStore.getState().isUnlocked;
  let networkVersion = '1';
  if (networkIdMap[chainEnum]) {
    networkVersion = networkIdMap[chainEnum];
  } else {
    networkVersion = await providerController.netVersion(req);
    networkIdMap[chainEnum] = networkVersion;
  }

  // TODO: should we throw error here?
  let chainItem = findChainByEnum(chainEnum);

  if (!chainItem) {
    if (appIsDev) {
      throw new Error(
        `[internalMethod::getProviderState] chain ${chainEnum} not found`
      );
    } else {
      console.warn(
        `[internalMethod::getProviderState] chain ${chainEnum} not found`
      );
      chainItem = CHAINS.ETH;
    }
  }

  return {
    chainId: chainItem.hex,
    isUnlocked,
    accounts: isUnlocked ? await providerController.ethAccounts(req) : [],
    networkVersion,
  };
};

const providerOverwrite = ({
  data: {
    params: [val],
  },
}) => {
  preferenceService.setHasOtherProvider(val);
  return true;
};

const hasOtherProvider = () => {
  preferenceService.setHasOtherProvider(true);
  const isRabby = preferenceService.getIsDefaultWallet();
  if (wallet.isUnlocked()) {
    setPopupIcon(isRabby ? 'rabby' : 'metamask');
  }
  return true;
};

const isDefaultWallet = ({ origin }) => {
  return preferenceService.getIsDefaultWallet(origin);
};

const getProviderConfig = ({ origin }: { origin: string }) => {
  const rdns = permissionService.getSite(origin)?.rdns;
  const isMetamaskMode = metamaskModeService.checkIsMetamaskMode(origin);
  return {
    rdns,
    isMetamaskMode,
  };
};

const resetProvider = ({ origin }: { origin: string }) => {
  const site = permissionService.getSite(origin);
  if (site) {
    permissionService.setSite({ ...site, rdns: undefined });
  }
};

const openInDesktop = async (req: ProviderRequest) => {
  const origin = req.session?.origin || req.origin;
  const policy = getOpenInDesktopPolicy(origin, req.sourceFrameId);
  if (!policy) {
    throw ethErrors.provider.unauthorized();
  }

  if (policy.source === 'go-rabby') {
    const requestedTarget = req.data?.params?.[0]?.target;
    let desktopPath: string;
    switch (requestedTarget) {
      case 'perps':
        desktopPath = '/desktop/perps';
        break;
      case 'swap':
        desktopPath = '/desktop/profile?action=swap';
        break;
      case 'bridge':
        desktopPath = '/desktop/profile?action=bridge';
        break;
      case 'home':
      default:
        desktopPath = '/desktop/profile';
        break;
    }
    await wallet.openInDesktop(desktopPath);
    return { opened: true } as const;
  }

  const params: { address: string } = req.data?.params?.[0] || {};

  if (!keyringService.isUnlocked()) {
    wallet.openInDesktop(
      `/unlock?address=${encodeURIComponent(
        params.address || ''
      )}&from=${encodeURIComponent('/desktop/profile?utm_source=debank')}`
    );
    return;
  }
  if (params.address) {
    const account = await wallet.getAccountByAddress(params.address);
    const currentAccount = preferenceService.getCurrentAccount();
    if (
      account &&
      currentAccount &&
      account.address?.toLowerCase() !== currentAccount.address.toLowerCase()
    ) {
      preferenceService.setCurrentAccount(account);
    }
  }
  wallet.openInDesktop('/desktop/profile?utm_source=debank');
};

export default {
  tabCheckin,
  getProviderState,
  providerOverwrite,
  hasOtherProvider,
  isDefaultWallet,
  'rabby:getProviderConfig': getProviderConfig,
  'rabby:resetProvider': resetProvider,
  'rabby:openInDesktop': openInDesktop,
};
